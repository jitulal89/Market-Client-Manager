package com.marketclientmanager.app;

import android.content.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.GZIPInputStream;

public class PriceUpdateManager {
    public static int updateConfigured(Context ctx, DatabaseHelper db, String date) throws Exception {
        int contracts=0, prices=0;
        for(String ex:new String[]{"NSE","MCX","NCDEX"}){
            String url=db.setting(ex+"_URL");
            if(url==null||url.trim().isEmpty())continue;
            Result r=updateFromCsv(db,ex,url,date);contracts+=r.contracts;prices+=r.prices;
        }
        if(contracts==0&&prices==0)throw new Exception("No configured market-data URLs. Add an allowed CSV/Bhavcopy URL in Settings.");
        return contracts*1000000+prices;
    }
    public static Result updateFromCsv(DatabaseHelper db,String exchange,String url,String date)throws Exception{
        URL u=new URL(url);URLConnection con=u.openConnection();con.setConnectTimeout(15000);con.setReadTimeout(30000);con.setRequestProperty("User-Agent","MarketClientManager/1.0");
        InputStream raw=con.getInputStream();if(url.toLowerCase(Locale.US).contains(".gz"))raw=new GZIPInputStream(raw);
        BufferedReader br=new BufferedReader(new InputStreamReader(raw,StandardCharsets.UTF_8));String header=br.readLine();if(header==null)throw new Exception("Empty market-data file");
        String[] h=header.split(",",-1);Map<String,Integer> idx=new HashMap<>();for(int i=0;i<h.length;i++)idx.put(clean(h[i]),i);
        Result result=new Result();String line;
        while((line=br.readLine())!=null){String[] p=parseCsv(line);if(p.length<3)continue;
            String sym=get(p,idx,"SYMBOL","TckrSymb","SYMBOLNAME","CONTRACT");String expiry=get(p,idx,"EXPIRY","XPRYDT","EXPIRYDATE","FININSTRMACTLXPRYDT");
            String inst=get(p,idx,"INSTRUMENT","INSTRUMENTTYPE","FININSTRMTP","INSTRUMENTTYPE");String opt=get(p,idx,"OPTIONTYPE","OPTNTP","OPTION_TYPE");double strike=num(get(p,idx,"STRIKE","STRIKEPRICE","STRKPRIC"),0);double lot=num(get(p,idx,"LOTSIZE","LOT_SIZE","CONTRACTSIZE"),1);double tick=num(get(p,idx,"TICKSIZE","TICK_SIZE"),0.01);
            double open=num(get(p,idx,"OPEN","OPENPRICE","OPNPRIC"),0),high=num(get(p,idx,"HIGH","HIGHPRICE","HGHPRIC"),0),low=num(get(p,idx,"LOW","LOWPRICE","LWPRIC"),0),close=num(get(p,idx,"CLOSE","CLOSINGPRICE","CLSPRC"),0),prev=num(get(p,idx,"PREVCLOSE","PREVIOUSCLOSE","PRVSCLSGPRIC"),0),vol=num(get(p,idx,"VOLUME","TRADEQUANTITY","TRADGVOL"),0),oi=num(get(p,idx,"OI","OPENINTEREST","OPNINTRST"),0),sett=num(get(p,idx,"SETTLEMENT","SETTLEMENTPRICE","STTLMTPRC"),close);
            if(sym==null||sym.trim().isEmpty())continue; if(expiry==null)expiry="";
            db.upsertContract(exchange,sym,expiry,inst==null?"UNKNOWN":inst,strike,opt==null?"":opt,lot,tick,exchange+"_REMOTE",1);long cid=db.contractId(exchange,sym,expiry,inst==null?"UNKNOWN":inst,strike,opt==null?"":opt);if(cid<0)continue;result.contracts++;if(close!=0){db.upsertPrice(cid,date,open,high,low,close,prev,vol,oi,sett,exchange+"_REMOTE");result.prices++;}
        }br.close();return result;
    }
    static class Result{int contracts;int prices;}
    static String clean(String s){return s==null?"":s.replace("\"","").trim().toUpperCase(Locale.US).replace(" ","").replace("_","");}
    static String get(String[] p,Map<String,Integer> idx,String... keys){for(String k:keys){Integer i=idx.get(clean(k));if(i!=null&&i<p.length)return p[i].replace("\"","").trim();}return null;}
    static double num(String s,double d){try{return Double.parseDouble(s==null?"":s.replace(",",""));}catch(Exception e){return d;}}
    static String[] parseCsv(String line){List<String> out=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<line.length();i++){char c=line.charAt(i);if(c=='\"'){q=!q;}else if(c==','&&!q){out.add(b.toString());b.setLength(0);}else b.append(c);}out.add(b.toString());return out.toArray(new String[0]);}
    public static int updateCsv(Context ctx,DatabaseHelper db,String url,String date)throws Exception{return updateFromCsv(db,"NSE",url,date).prices;}
}
