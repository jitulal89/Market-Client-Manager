package com.marketclientmanager.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DatabaseHelper db; LinearLayout root; final int PAD=18; ArrayList<Long> ids=new ArrayList<>();
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        showStartupMessage("Starting Market Client Manager…");
        try {
            initializeDatabase();
            try { scheduleBackup(); } catch (Throwable ignored) { }
            home();
        } catch (Throwable e) {
            showStartupError(e);
        }
    }

    private void initializeDatabase() {
        if (db != null) { try { db.close(); } catch (Exception ignored) { } }
        db = new DatabaseHelper(getApplicationContext());
        db.seed();
        // Touch the database after seeding so a partially initialized database
        // fails here with a useful diagnostic instead of crashing later in home().
        db.contractCount();
        db.priceCount(today());
    }

    private void showStartupMessage(String message) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(PAD, PAD, PAD, PAD);
        TextView t = new TextView(this);
        t.setText(message);
        t.setTextSize(20);
        l.addView(t);
        setContentView(l);
    }

    private void showStartupError(Throwable error) {
        String msg = error == null ? "Unknown startup error" : error.toString();
        if (error != null && error.getCause() != null) msg += "\nCause: " + error.getCause();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(PAD, PAD, PAD, PAD);
        TextView title = new TextView(this);
        title.setText("Market Client Manager could not start");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(183, 28, 28));
        l.addView(title);
        TextView detail = new TextView(this);
        detail.setText("The app detected a local database/startup problem.\n\n" + msg);
        detail.setTextIsSelectable(true);
        detail.setPadding(0, PAD, 0, PAD);
        l.addView(detail);
        Button retry = btn("Retry");
        retry.setOnClickListener(v -> {
            try {
                showStartupMessage("Starting Market Client Manager…");
                initializeDatabase();
                try { scheduleBackup(); } catch (Throwable ignored) { }
                home();
            } catch (Throwable e) {
                showStartupError(e);
            }
        });
        l.addView(retry);
        setContentView(l);
    }
    void scheduleBackup(){AlarmManager a=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,DailyBackupReceiver.class);PendingIntent p=PendingIntent.getBroadcast(this,77,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,20);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);a.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,p);}
    TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(22);t.setTextColor(Color.rgb(21,101,192));t.setPadding(PAD,PAD,PAD,10);return t;}
    TextView info(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(14);t.setPadding(PAD,8,PAD,8);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setPadding(PAD,8,PAD,8);return e;}
    void base(String name){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);root.addView(title(name));}
    void home(){base("Market Client Manager");root.addView(info("Offline-first client trading, settlement, brokerage, sub-broker and reporting app"));root.addView(btnx("Clients",v->clients()));root.addView(btnx("Sub Brokers / Referral Partners",v->subBrokers()));root.addView(btnx("Daily Trade Entry",v->trade()));root.addView(btnx("Market Data / Contract Master",v->marketData()));root.addView(btnx("Daily MTM / Weekly Settlement",v->settlement()));root.addView(btnx("Payments / Client Ledger",v->payments()));root.addView(btnx("Daily / Weekly Reports",v->reports()));root.addView(btnx("Sub Broker Reports / Payments",v->subBrokerReports()));root.addView(btnx("Backup & Restore",v->backup()));root.addView(btnx("Settings / Data Sources",v->settings()));root.addView(info("Contracts in SQLite: "+db.contractCount()+"\nToday's prices: "+db.priceCount(today())));}
    Button btnx(String s,View.OnClickListener l){Button b=btn(s);b.setOnClickListener(l);root.addView(b);return b;}

    void clients(){base("Clients");btnx("+ Add Client",v->addClient());Cursor c=db.clients();while(c.moveToNext()){long id=c.getLong(0);long sb=c.getLong(7);String referral=sb>0?" | Sub Broker: "+db.subBrokerName(sb):" | No Sub Broker";String s=c.getString(1)+"  ["+c.getString(2)+"]  Balance: "+money(db.balance(id,today()))+referral;btnx(s,v->clientDetail(id));}c.close();btnx("Home",v->home());}

    void addClient(){base("Add Client");EditText n=edit("Client name *"),code=edit("Client code"),phone=edit("Phone"),email=edit("Email"),bal=edit("Opening balance (positive = Dr)");root.addView(n);root.addView(code);root.addView(phone);root.addView(email);
        Spinner sb=new Spinner(this);ArrayList<Long> sbIds=new ArrayList<>();ArrayList<String> sbNames=new ArrayList<>();sbIds.add(0L);sbNames.add("No Sub Broker / Direct Client");Cursor sc=db.subBrokers();while(sc.moveToNext()){sbIds.add(sc.getLong(0));sbNames.add(sc.getString(1)+" - "+sc.getString(2));}sc.close();sb.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sbNames));root.addView(info("Referred By / Sub Broker"));root.addView(sb);
        EditText sbN=edit("NSE Sub Broker share per crore (₹)"),sbM=edit("MCX Sub Broker share per crore (₹)"),sbC=edit("NCDEX Sub Broker share per crore (₹)");sbN.setText("1000");sbM.setText("1000");sbC.setText("1000");root.addView(info("Sub Broker share / brokerage"));root.addView(sbN);root.addView(sbM);root.addView(sbC);root.addView(bal);
        btnx("Save Client",v->{try{if(n.getText().toString().trim().isEmpty())throw new Exception("Client name required");long id=db.addClient(n.getText().toString(),code.getText().toString(),phone.getText().toString(),email.getText().toString());db.setBrokerage(id,"NSE","PER_CRORE",3000);db.setBrokerage(id,"MCX","PER_CRORE",3000);db.setBrokerage(id,"NCDEX","PER_CRORE",3000);long sbi=sbIds.get(sb.getSelectedItemPosition());if(sbi>0){db.setClientSubBroker(id,sbi);db.setSubBrokerage(id,sbi,"NSE","PER_CRORE",Double.parseDouble(sbN.getText().toString()),today());db.setSubBrokerage(id,sbi,"MCX","PER_CRORE",Double.parseDouble(sbM.getText().toString()),today());db.setSubBrokerage(id,sbi,"NCDEX","PER_CRORE",Double.parseDouble(sbC.getText().toString()),today());}if(bal.getText().length()>0)db.setOpeningBalance(id,today(),Double.parseDouble(bal.getText().toString()));clientDetail(id);}catch(Exception e){toast(e.getMessage());}});btnx("Back",v->clients());}

    void clientDetail(long id){base("Client: "+db.clientName(id));long sbid=db.clientSubBroker(id);root.addView(info("Current balance: "+money(db.balance(id,today()))+"\nSub Broker: "+(sbid>0?db.subBrokerName(sbid)+" ["+db.subBrokerCode(sbid)+"]":"Direct / None")));root.addView(title("Client Brokerage + Sub Brokerage"));
        for(String ex:new String[]{"NSE","MCX","NCDEX"}){EditText e=edit(ex+" client brokerage per crore (₹)");e.setText("3000");root.addView(e);btnx("Save "+ex+" Client Brokerage",v->{try{db.setBrokerage(id,ex,"PER_CRORE",Double.parseDouble(e.getText().toString()));toast("Client brokerage saved");}catch(Exception z){toast("Enter a number");}});if(sbid>0){EditText se=edit(ex+" sub-broker share per crore (₹)");se.setText("1000");root.addView(se);btnx("Save "+ex+" Sub Broker Share",v->{try{db.setSubBrokerage(id,sbid,ex,"PER_CRORE",Double.parseDouble(se.getText().toString()),today());toast("Sub-broker share saved");}catch(Exception z){toast("Enter a number");}});}}
        btnx("Change / Remove Sub Broker",v->changeClientSubBroker(id));btnx("Add Payment",v->paymentFor(id));btnx("View Ledger",v->ledger(id));btnx("Back",v->clients());}

    void changeClientSubBroker(long id){base("Sub Broker - "+db.clientName(id));Spinner sb=new Spinner(this);ArrayList<Long> sbIds=new ArrayList<>();ArrayList<String> names=new ArrayList<>();sbIds.add(0L);names.add("Direct / No Sub Broker");Cursor c=db.subBrokers();while(c.moveToNext()){sbIds.add(c.getLong(0));names.add(c.getString(1)+" - "+c.getString(2));}c.close();sb.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(sb);btnx("Save Sub Broker",v->{db.setClientSubBroker(id,sbIds.get(sb.getSelectedItemPosition()));toast("Sub Broker updated");clientDetail(id);});btnx("Back",v->clientDetail(id));}

    void subBrokers(){base("Sub Brokers / Referral Partners");btnx("+ Add Sub Broker",v->addSubBroker());Cursor c=db.subBrokers();while(c.moveToNext()){long id=c.getLong(0);String s=c.getString(1)+" - "+c.getString(2)+" | Clients: "+countSubBrokerClients(id)+" | Balance: "+money(db.subBrokerBalance(id,today()));btnx(s,v->subBrokerDetail(id));}c.close();btnx("Home",v->home());}
    int countSubBrokerClients(long sb){Cursor c=db.clientsForSubBroker(sb);int n=0;while(c.moveToNext())n++;c.close();return n;}
    void addSubBroker(){base("Add Sub Broker / Referral Partner");EditText code=edit("Sub Broker code *"),name=edit("Name *"),phone=edit("Phone"),email=edit("Email"),address=edit("Address"),bank=edit("Bank / Payment details"),opening=edit("Opening balance payable to sub broker");root.addView(code);root.addView(name);root.addView(phone);root.addView(email);root.addView(address);root.addView(bank);root.addView(opening);btnx("Save Sub Broker",v->{try{if(code.getText().toString().trim().isEmpty()||name.getText().toString().trim().isEmpty())throw new Exception("Code and name required");long id=db.addSubBroker(code.getText().toString().trim(),name.getText().toString().trim(),phone.getText().toString(),email.getText().toString(),address.getText().toString(),bank.getText().toString());if(opening.getText().length()>0)db.setSubBrokerOpeningBalance(id,today(),Double.parseDouble(opening.getText().toString()));subBrokers();}catch(Exception e){toast(e.getMessage());}});btnx("Back",v->subBrokers());}
    void subBrokerDetail(long sb){base("Sub Broker: "+db.subBrokerName(sb));root.addView(info("Code: "+db.subBrokerCode(sb)+"\nCurrent outstanding payable: "+money(db.subBrokerBalance(sb,today()))+"\nPeriod earnings: "+money(db.subBrokerEarningsTotal(sb,monthStart(),today()))));btnx("View Referred Clients",v->subBrokerClients(sb));btnx("Record Payment to Sub Broker",v->subBrokerPayment(sb));btnx("View Sub Broker Ledger",v->subBrokerLedger(sb));btnx("View Earnings",v->subBrokerEarnings(sb));btnx("Back",v->subBrokers());}
    void subBrokerClients(long sb){base("Clients Referred by "+db.subBrokerName(sb));Cursor c=db.clientsForSubBroker(sb);while(c.moveToNext()){long id=c.getLong(0);btnx(c.getString(1)+" ["+c.getString(2)+"] | "+money(db.balance(id,today())),v->clientDetail(id));}c.close();btnx("Back",v->subBrokerDetail(sb));}
    void subBrokerPayment(long sb){base("Payment to Sub Broker - "+db.subBrokerName(sb));EditText d=edit("Payment date YYYY-MM-DD"),a=edit("Amount"),r=edit("Reference / UTR"),m=edit("Remarks");d.setText(today());Spinner typ=new Spinner(this);typ.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Bank Transfer","NEFT","RTGS","IMPS","UPI","Cheque","Cash","Other"}));root.addView(d);root.addView(a);root.addView(typ);root.addView(r);root.addView(m);btnx("Save Sub Broker Payment",v->{try{db.addSubBrokerPayment(sb,d.getText().toString(),Double.parseDouble(a.getText().toString()),typ.getSelectedItem().toString(),r.getText().toString(),m.getText().toString());toast("Payment saved. Outstanding = "+money(db.subBrokerBalance(sb,d.getText().toString())));subBrokerDetail(sb);}catch(Exception e){toast(e.getMessage());}});btnx("Back",v->subBrokerDetail(sb));}
    void subBrokerLedger(long sb){base("Sub Broker Ledger - "+db.subBrokerName(sb));EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);btnx("Refresh Ledger",v->showSubBrokerLedger(sb,f.getText().toString(),t.getText().toString()));showSubBrokerLedger(sb,f.getText().toString(),t.getText().toString());btnx("Back",v->subBrokerDetail(sb));}
    void showSubBrokerLedger(long sb,String f,String t){Cursor c=db.subBrokerLedger(sb,f,t);StringBuilder s=new StringBuilder("Date | Type | Debit | Credit\n\n");while(c.moveToNext())s.append(c.getString(0)).append(" | ").append(c.getString(1)).append("\n").append(c.getString(2)).append("\nDr ").append(money(c.getDouble(3))).append("  Cr ").append(money(c.getDouble(4))).append("\n\n");c.close();root.addView(info(s.toString()+"\nCurrent outstanding: "+money(db.subBrokerBalance(sb,t))));}
    void subBrokerEarnings(long sb){base("Sub Broker Earnings - "+db.subBrokerName(sb));EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);btnx("Refresh Earnings",v->showSubBrokerEarnings(sb,f.getText().toString(),t.getText().toString()));showSubBrokerEarnings(sb,f.getText().toString(),t.getText().toString());btnx("Back",v->subBrokerDetail(sb));}
    void showSubBrokerEarnings(long sb,String f,String t){Cursor c=db.subBrokerEarnings(sb,f,t);StringBuilder s=new StringBuilder("Date | Client | Exchange | Turnover | Client Brokerage | Sub Broker Earned\n\n");while(c.moveToNext())s.append(c.getString(0)).append(" | ").append(c.getString(1)).append(" | ").append(c.getString(2)).append("\nTurnover ").append(money(c.getDouble(3))).append(" | Brokerage ").append(money(c.getDouble(4))).append(" | Earned ").append(money(c.getDouble(5))).append("\n\n");c.close();s.append("Period total: ").append(money(db.subBrokerEarningsTotal(sb,f,t)));root.addView(info(s.toString()));}

    void trade(){base("Daily Trade Entry");Spinner cs=new Spinner(this);Cursor cc=db.clients();ids.clear();ArrayList<String> cn=new ArrayList<>();while(cc.moveToNext()){ids.add(cc.getLong(0));cn.add(cc.getString(1)+" | "+(cc.getLong(7)>0?db.subBrokerName(cc.getLong(7)):"Direct"));}cc.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cn));root.addView(cs);Spinner ks=new Spinner(this);ArrayList<Long> cons=new ArrayList<>();ArrayList<String> kn=new ArrayList<>();Cursor ct=db.contracts();while(ct.moveToNext()){cons.add(ct.getLong(0));kn.add(ct.getString(1)+" / "+ct.getString(2)+" / "+ct.getString(3)+" / "+ct.getString(4)+" / lot "+ct.getDouble(7));}ct.close();ks.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,kn));root.addView(ks);Spinner side=new Spinner(this);side.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"BUY","SELL"}));root.addView(side);EditText date=edit("Trade date YYYY-MM-DD"),lots=edit("Lots (optional)"),qty=edit("Quantity (optional; overrides lots)"),rate=edit("Trade price"),notes=edit("Notes");date.setText(today());root.addView(date);root.addView(lots);root.addView(qty);root.addView(rate);root.addView(notes);root.addView(info("When the client has a Sub Broker, the configured Sub Broker share is calculated automatically and posted to the separate Sub Broker earnings/ledger."));btnx("Save Trade",v->{try{long client=ids.get(cs.getSelectedItemPosition()),con=cons.get(ks.getSelectedItemPosition());double lot=db.getLotSize(con),l=empty(lots)?0:Double.parseDouble(lots.getText().toString()),q=!empty(qty)?Double.parseDouble(qty.getText().toString()):l*lot;if(q<=0)throw new Exception("Quantity required");double r=Double.parseDouble(rate.getText().toString());db.addTransaction(client,con,date.getText().toString(),side.getSelectedItem().toString(),l,q,r,notes.getText().toString());toast("Saved. Qty="+q+" Lot size="+lot);lots.setText("");qty.setText("");rate.setText("");}catch(Exception e){toast(e.getMessage());}});btnx("Home",v->home());}
    void marketData(){base("Market Data / Contract Master");EditText d=edit("Price date YYYY-MM-DD");d.setText(today());root.addView(d);root.addView(info("One action updates configured NSE/MCX/NCDEX contract master first, then daily prices. New expiries, strikes and contracts are added without deleting history."));btnx("Update Contract Master + Closing Prices",v->{try{int x=PriceUpdateManager.updateConfigured(this,db,d.getText().toString());int p=x%1000000,c=x/1000000;toast("Updated "+c+" contract rows and "+p+" prices");}catch(Exception e){toast(e.getMessage());}});btnx("View Contract Count",v->toast("SQLite contracts: "+db.contractCount()));btnx("Back",v->home());}
    void settlement(){base("Daily MTM / Weekly Settlement");Spinner cs=new Spinner(this);Cursor c=db.clients();ids.clear();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));}c.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(cs);EditText d=edit("Processing date YYYY-MM-DD");d.setText(today());root.addView(d);btnx("Process Daily MTM",v->{try{double x=db.processDailyMtm(ids.get(cs.getSelectedItemPosition()),d.getText().toString());toast("Daily MTM = "+money(x));}catch(Exception e){toast(e.getMessage());}});btnx("Settle Week / Carry Forward",v->{try{double x=db.settleWeek(ids.get(cs.getSelectedItemPosition()),d.getText().toString());toast("Weekly settlement = "+money(x)+". Settlement price is now the next carry-forward base.");}catch(Exception e){toast(e.getMessage());}});btnx("Back",v->home());}
    void payments(){base("Payments / Client Ledger");Spinner cs=new Spinner(this);Cursor c=db.clients();ids.clear();ArrayList<String> n=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));n.add(c.getString(1));}c.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,n));root.addView(cs);btnx("Record Payment",v->paymentFor(ids.get(cs.getSelectedItemPosition())));btnx("View Ledger",v->ledger(ids.get(cs.getSelectedItemPosition())));btnx("Back",v->home());}
    void paymentFor(long client){base("Record Payment - "+db.clientName(client));EditText d=edit("Payment date YYYY-MM-DD"),a=edit("Amount"),r=edit("Reference / UTR"),m=edit("Remarks");d.setText(today());Spinner typ=new Spinner(this);typ.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Bank Transfer","NEFT","RTGS","IMPS","UPI","Cheque","Cash","Other"}));root.addView(d);root.addView(a);root.addView(typ);root.addView(r);root.addView(m);btnx("Save Payment",v->{try{db.addPayment(client,d.getText().toString(),Double.parseDouble(a.getText().toString()),typ.getSelectedItem().toString(),r.getText().toString(),m.getText().toString());toast("Payment saved. Balance = "+money(db.balance(client,d.getText().toString())));clientDetail(client);}catch(Exception e){toast(e.getMessage());}});btnx("Back",v->clientDetail(client));}
    void ledger(long client){base("Ledger - "+db.clientName(client));EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);btnx("Refresh Ledger",v->showLedger(client,f.getText().toString(),t.getText().toString()));showLedger(client,f.getText().toString(),t.getText().toString());btnx("Back",v->clientDetail(client));}
    void showLedger(long client,String f,String t){Cursor c=db.ledger(client,f,t);StringBuilder s=new StringBuilder("Date | Type | Debit | Credit\n\n");while(c.moveToNext())s.append(c.getString(0)).append(" | ").append(c.getString(1)).append("\n").append(c.getString(2)).append("\nDr ").append(money(c.getDouble(3))).append("  Cr ").append(money(c.getDouble(4))).append("\n\n");c.close();root.addView(info(s.toString()+"\nCurrent balance: "+money(db.balance(client,t))));}
    void reports(){base("Daily / Weekly Reports");Spinner cs=new Spinner(this);Cursor c=db.clients();ids.clear();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));}c.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(cs);EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(today());t.setText(today());root.addView(f);root.addView(t);btnx("Generate PDF + Share",v->{try{File file=PdfReportGenerator.generate(this,db,ids.get(cs.getSelectedItemPosition()),f.getText().toString(),t.getText().toString());Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,androidx.core.content.FileProvider.getUriForFile(this,getPackageName()+".backup",file));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share report"));}catch(Exception e){toast(e.getMessage());}});btnx("Process Daily MTM Before Report",v->{try{toast("MTM = "+money(db.processDailyMtm(ids.get(cs.getSelectedItemPosition()),t.getText().toString())));}catch(Exception e){toast(e.getMessage());}});btnx("Back",v->home());}
    void subBrokerReports(){base("Sub Broker Reports / Payments");Cursor c=db.subBrokers();ids.clear();ArrayList<Long> sbIds=new ArrayList<>();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){sbIds.add(c.getLong(0));names.add(c.getString(1)+" - "+c.getString(2)+" | Outstanding "+money(db.subBrokerBalance(c.getLong(0),today())));}c.close();Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(s);EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);btnx("View Selected Sub Broker",v->{if(sbIds.size()>0)subBrokerDetail(sbIds.get(s.getSelectedItemPosition()));else toast("No sub brokers registered");});btnx("View Earnings",v->{if(sbIds.size()>0)subBrokerEarnings(sbIds.get(s.getSelectedItemPosition()));});btnx("Record Payment",v->{if(sbIds.size()>0)subBrokerPayment(sbIds.get(s.getSelectedItemPosition()));});btnx("Back",v->home());}
    void backup(){base("Backup & Restore");root.addView(info("Automatic daily backup is scheduled. Backups are stored locally first and can be shared using Android Share Sheet. Backup includes client/sub-broker masters, brokerage, earnings, ledgers, payments, trades, positions and market data."));btnx("Backup Now",v->{try{toast("Created: "+BackupManager.backup(this).getName());}catch(Exception e){toast(e.getMessage());}});btnx("Share Latest Backup",v->{try{File f=BackupManager.latest(this);if(!f.exists())f=BackupManager.backup(this);startActivity(Intent.createChooser(BackupManager.share(this,f),"Share backup"));}catch(Exception e){toast(e.getMessage());}});btnx("Restore Backup",v->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/octet-stream").addCategory(Intent.CATEGORY_OPENABLE),9001));btnx("Show Backup History",v->{File[] fs=BackupManager.history(this);StringBuilder s=new StringBuilder();for(File f:fs)s.append(f.getName()).append("\n");toast(s.length()==0?"No backups":s.toString());});btnx("Back",v->home());}
    @Override protected void onActivityResult(int r,int result,Intent d){super.onActivityResult(r,result,d);if(r==9001&&result==RESULT_OK&&d!=null)try{BackupManager.restore(this,d.getData());toast("Restore complete. Restarting app.");new Handler().postDelayed(this::recreate,1000);}catch(Exception e){toast("Restore failed: "+e.getMessage());}}
    void settings(){base("Settings / Market Data Sources");root.addView(info("Use only allowed public/downloadable market-data sources. The app does not bypass exchange access controls. Configure CSV/UDiFF/Bhavcopy endpoints you are permitted to use."));for(String ex:new String[]{"NSE","MCX","NCDEX"}){EditText e=edit(ex+" CSV/Bhavcopy URL");e.setText(db.setting(ex+"_URL"));root.addView(e);e.setTag(ex);}btnx("Save URLs",v->{for(int i=0;i<root.getChildCount();i++){View z=root.getChildAt(i);if(z instanceof EditText&&z.getTag()!=null)db.setting(z.getTag().toString(),((EditText)z).getText().toString());}toast("Saved");});btnx("Back",v->home());}
    boolean empty(EditText e){return e.getText().toString().trim().isEmpty();}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String monthStart(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_MONTH,1);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    String money(double x){return String.format(Locale.US,"₹%,.2f %s",Math.abs(x),x<0?"Dr":"Cr");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
