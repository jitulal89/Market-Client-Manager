package com.marketclientmanager.app;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME="market_client_manager.db";
    public static final int DB_VERSION=12;
    private final Context appContext;
    public DatabaseHelper(Context c){super(c,DB_NAME,null,DB_VERSION);appContext=c.getApplicationContext();}

    @Override public void onCreate(SQLiteDatabase db){ createSchema(db); }
    private void createSchema(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS sub_brokers(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL UNIQUE,name TEXT NOT NULL,phone TEXT,email TEXT,address TEXT,status TEXT DEFAULT 'ACTIVE',bank_details TEXT,opening_balance REAL DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT,phone TEXT,email TEXT,status TEXT DEFAULT 'ACTIVE',previous_balance REAL DEFAULT 0,opening_balance_date TEXT,sub_broker_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE IF NOT EXISTS brokerage(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,exchange_code TEXT NOT NULL,method TEXT DEFAULT 'PER_CRORE',rate REAL DEFAULT 0,UNIQUE(client_id,exchange_code))");
        db.execSQL("CREATE TABLE IF NOT EXISTS sub_broker_brokerage(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,sub_broker_id INTEGER NOT NULL,exchange_code TEXT NOT NULL,method TEXT DEFAULT 'PER_CRORE',rate REAL DEFAULT 0,effective_from TEXT,UNIQUE(client_id,exchange_code))");
        db.execSQL("CREATE TABLE IF NOT EXISTS contracts(id INTEGER PRIMARY KEY AUTOINCREMENT,exchange_code TEXT NOT NULL,symbol TEXT NOT NULL,expiry TEXT,instrument_type TEXT,strike REAL DEFAULT 0,option_type TEXT,lot_size REAL DEFAULT 1,lot_unit TEXT DEFAULT 'UNIT',quote_size REAL DEFAULT 1,quote_unit TEXT DEFAULT 'UNIT',tick_size REAL DEFAULT 0.01,lot_size_verified INTEGER DEFAULT 0,active INTEGER DEFAULT 1,source TEXT,updated_at TEXT,UNIQUE(exchange_code,symbol,expiry,instrument_type,strike,option_type))");
        db.execSQL("CREATE TABLE IF NOT EXISTS prices(id INTEGER PRIMARY KEY AUTOINCREMENT,contract_id INTEGER NOT NULL,price_date TEXT NOT NULL,open REAL,high REAL,low REAL,close REAL,previous_close REAL,volume REAL,open_interest REAL,settlement REAL,source TEXT,UNIQUE(contract_id,price_date))");
        db.execSQL("CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,contract_id INTEGER NOT NULL,trade_date TEXT NOT NULL,side TEXT NOT NULL,lots REAL DEFAULT 0,quantity REAL NOT NULL,rate REAL NOT NULL,turnover REAL NOT NULL,brokerage REAL DEFAULT 0,sub_broker_id INTEGER,sub_brokerage REAL DEFAULT 0,net_amount REAL DEFAULT 0,notes TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE IF NOT EXISTS daily_mtm(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,contract_id INTEGER NOT NULL,mtm_date TEXT NOT NULL,base_price REAL NOT NULL,close_price REAL NOT NULL,quantity REAL NOT NULL,mtm REAL NOT NULL,UNIQUE(client_id,contract_id,mtm_date))");
        db.execSQL("CREATE TABLE IF NOT EXISTS weekly_settlements(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,contract_id INTEGER NOT NULL,settlement_date TEXT NOT NULL,quantity REAL NOT NULL,base_price REAL NOT NULL,settlement_price REAL NOT NULL,mtm REAL NOT NULL,UNIQUE(client_id,contract_id,settlement_date))");
        db.execSQL("CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,payment_date TEXT NOT NULL,amount REAL NOT NULL,payment_type TEXT NOT NULL,reference TEXT,remarks TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,client_id INTEGER NOT NULL,entry_date TEXT NOT NULL,entry_type TEXT NOT NULL,description TEXT,debit REAL DEFAULT 0,credit REAL DEFAULT 0,reference_id INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS sub_broker_earnings(id INTEGER PRIMARY KEY AUTOINCREMENT,sub_broker_id INTEGER NOT NULL,client_id INTEGER NOT NULL,transaction_id INTEGER,earning_date TEXT NOT NULL,exchange_code TEXT,turnover REAL DEFAULT 0,brokerage REAL DEFAULT 0,earning REAL DEFAULT 0,description TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS sub_broker_payments(id INTEGER PRIMARY KEY AUTOINCREMENT,sub_broker_id INTEGER NOT NULL,payment_date TEXT NOT NULL,amount REAL NOT NULL,payment_type TEXT NOT NULL,reference TEXT,remarks TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE IF NOT EXISTS sub_broker_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,sub_broker_id INTEGER NOT NULL,entry_date TEXT NOT NULL,entry_type TEXT NOT NULL,description TEXT,debit REAL DEFAULT 0,credit REAL DEFAULT 0,reference_id INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_tx_client_date ON transactions(client_id,trade_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_price_date ON prices(price_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_ledger_client_date ON ledger(client_id,entry_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sb_ledger_date ON sub_broker_ledger(sub_broker_id,entry_date)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sb_earnings_date ON sub_broker_earnings(sub_broker_id,earning_date)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){
        if(oldV<3){safeAdd(db,"clients","opening_balance_date","TEXT");safeAdd(db,"clients","created_at","TEXT");}
        if(oldV<4){createSchema(db);}
        if(oldV<5){createSchema(db);}
        if(oldV<6){safeAdd(db,"clients","sub_broker_id","INTEGER");safeAdd(db,"transactions","sub_broker_id","INTEGER");safeAdd(db,"transactions","sub_brokerage","REAL DEFAULT 0");createSchema(db);}
        if(oldV<7){createSchema(db);}
        if(oldV<8){safeAdd(db,"contracts","lot_unit","TEXT DEFAULT 'UNIT'");safeAdd(db,"contracts","quote_size","REAL DEFAULT 1");safeAdd(db,"contracts","quote_unit","TEXT DEFAULT 'UNIT'");}
        if(oldV<9){upgradeGoldCatalog(db);}
        if(oldV<10){upgradeCommodityLotCatalog(db);}
        if(oldV<11){cleanupInvalidNseContracts(db);}
        if(oldV<12){upgradeExchangeContractCatalog(db);}
        seedContractCatalog(db);
    }
    private void upgradeGoldCatalog(SQLiteDatabase db){
        try{db.execSQL("UPDATE contracts SET lot_size=1,lot_unit='KG',quote_size=10,quote_unit='GM' WHERE exchange_code='MCX' AND symbol='GOLD'");
            String[] exps={"05OCT2026","04DEC2026","05FEB2027","05APR2027","04JUN2027"};
            for(String exp:exps){ContentValues v=new ContentValues();v.put("exchange_code","MCX");v.put("symbol","GOLD");v.put("expiry",exp);v.put("instrument_type","FUTURE");v.put("strike",0);v.put("option_type","");v.put("lot_size",1);v.put("lot_unit","KG");v.put("quote_size",10);v.put("quote_unit","GM");v.put("tick_size",0.05);v.put("lot_size_verified",1);v.put("active",1);v.put("source","MCX_OFFICIAL_REFERENCE");v.put("updated_at",now());db.insertWithOnConflict("contracts",null,v,SQLiteDatabase.CONFLICT_IGNORE);}
        }catch(Exception ignored){}
    }
    private void upgradeCommodityLotCatalog(SQLiteDatabase db){
        try{
            db.execSQL("UPDATE contracts SET lot_size=1000,lot_unit='KG',quote_size=1,quote_unit='KG',lot_size_verified=1,source='MCX_OFFICIAL_REFERENCE' WHERE exchange_code='MCX' AND symbol='ALUMINI'");
            db.execSQL("UPDATE contracts SET lot_size=5000,lot_unit='KG',quote_size=1,quote_unit='KG',lot_size_verified=1,source='MCX_OFFICIAL_REFERENCE' WHERE exchange_code='MCX' AND symbol='ALUMINIUM'");
        }catch(Exception ignored){}
    }
    private void upgradeExchangeContractCatalog(SQLiteDatabase db){
        try{
            // MCX futures contract specifications used when the EOD bhavcopy does not
            // carry market-lot metadata. Values are stored in the contract's actual
            // lot unit and price quotation unit.
            String[][] specs={
                {"GOLD","1","KG","10","GM"},
                {"GOLDM","100","GM","10","GM"},
                {"GOLDTEN","10","GM","10","GM"},
                {"GOLDGUINEA","8","GM","8","GM"},
                {"GOLDPETAL","1","GM","1","GM"},
                {"SILVER","30","KG","1","KG"},
                {"SILVERM","5","KG","1","KG"},
                {"SILVERMIC","1","KG","1","KG"},
                {"SILVER100","100","GM","100","GM"},
                {"COPPER","2500","KG","1","KG"},
                {"ALUMINIUM","5000","KG","1","KG"},
                {"ALUMINI","1000","KG","1","KG"},
                {"LEAD","5000","KG","1","KG"},
                {"LEADMINI","1000","KG","1","KG"},
                {"NICKEL","1500","KG","1","KG"},
                {"ZINC","5000","KG","1","KG"},
                {"ZINCMINI","1000","KG","1","KG"},
                {"CRUDEOIL","100","BARREL","1","BARREL"},
                {"CRUDEOILM","10","BARREL","1","BARREL"},
                {"NATURALGAS","1250","MMBTU","1","MMBTU"},
                {"NATGASMINI","250","MMBTU","1","MMBTU"},
                {"CARDAMOM","100","KG","1","KG"},
                {"COTTON","25","BALE","1","BALE"},
                {"COTTONOIL","5000","KG","10","KG"},
                {"MENTHAOIL","360","KG","1","KG"},
                {"CPO","10000","KG","10","KG"},
                {"KAPAS","4000","KG","20","KG"}
            };
            for(String[] s:specs){
                ContentValues v=new ContentValues();
                v.put("lot_size",Double.parseDouble(s[1])); v.put("lot_unit",s[2]);
                v.put("quote_size",Double.parseDouble(s[3])); v.put("quote_unit",s[4]);
                v.put("lot_size_verified",1); v.put("source","MCX_OFFICIAL_REFERENCE");
                db.update("contracts",v,"exchange_code='MCX' AND symbol=?",new String[]{s[0]});
            }
        }catch(Exception ignored){}
    }
    private void safeAdd(SQLiteDatabase db,String t,String c,String typ){try{db.execSQL("ALTER TABLE "+t+" ADD COLUMN "+c+" "+typ);}catch(Exception ignored){}}
    public void cleanupInvalidNseContracts(){ cleanupInvalidNseContracts(getWritableDatabase()); }
    private void cleanupInvalidNseContracts(SQLiteDatabase db){
        try{
            Cursor c=db.rawQuery("SELECT id,symbol FROM contracts WHERE exchange_code='NSE' AND active=1",null);
            while(c.moveToNext()){
                long id=c.getLong(0); String s=c.getString(1)==null?"":c.getString(1).trim().toUpperCase(Locale.US);
                boolean bad=s.contains("NSETEST") || s.matches("\\d{3,}[A-Z&-]+\\d{2,}.*");
                if(bad){ContentValues v=new ContentValues();v.put("active",0);db.update("contracts",v,"id=?",new String[]{""+id});}
            } c.close();
        }catch(Exception ignored){}
    }

    public void seed(){
        SQLiteDatabase db=getWritableDatabase(); seedContractCatalog(db); upgradeGoldCatalog(db); upgradeExchangeContractCatalog(db); cleanupInvalidNseContracts(db);
        Cursor c=db.rawQuery("SELECT COUNT(*) FROM clients",null);c.moveToFirst();long n=c.getLong(0);c.close();
        if(n==0){long a=addClient("TEJAS JALARAM","TEJAS-001","","");setBrokerage(a,"NSE","PER_CRORE",3000);setBrokerage(a,"MCX","PER_CRORE",3000);setBrokerage(a,"NCDEX","PER_CRORE",3000);}
        addContractIfMissing(db,"NSE","CIPLA","29DEC22",650,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","COLPAL","29DEC22",350,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","DABUR","29DEC22",1250,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","INFY","29DEC22",300,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","IRCTC","29DEC22",875,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","TATACOMM","29DEC22",500,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","TATAMOTORS","29DEC22",1425,0.05,1,"SAMPLE");
        addContractIfMissing(db,"NSE","TITAN","29DEC22",375,0.05,1,"SAMPLE");
    }
    private void addContractIfMissing(SQLiteDatabase db,String ex,String sym,String expiry,double lot,double tick,int verified,String source){
        ContentValues v=new ContentValues();v.put("exchange_code",ex);v.put("symbol",sym);v.put("expiry",expiry);v.put("instrument_type","FUTURE");v.put("strike",0);v.put("option_type","");v.put("lot_size",lot);v.put("lot_unit",ex.equals("NSE")?"SHARE":"UNIT");v.put("quote_size",1);v.put("quote_unit",ex.equals("NSE")?"SHARE":"UNIT");v.put("tick_size",tick);v.put("lot_size_verified",verified);v.put("active",1);v.put("source",source);v.put("updated_at",now());db.insertWithOnConflict("contracts",null,v,SQLiteDatabase.CONFLICT_IGNORE);
    }
    private void seedContractCatalog(SQLiteDatabase db){
        Cursor c=db.rawQuery("SELECT COUNT(*) FROM contracts",null);c.moveToFirst();long count=c.getLong(0);c.close();if(count>0)return;
        boolean inTx=false;
        try(InputStream in=appContext.getAssets().open("contracts_seed.csv");BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
            String line;boolean header=true;db.beginTransaction();inTx=true;
            while((line=br.readLine())!=null){
                if(header){header=false;continue;}
                if(line.trim().isEmpty())continue;
                String[] p=line.split(",",-1);
                if(p.length<7)continue;
                ContentValues v=new ContentValues();
                v.put("exchange_code",p[0].trim());v.put("symbol",p[1].trim());v.put("expiry",p[6].trim());
                v.put("instrument_type",p[3].trim());v.put("strike",0);v.put("option_type","");
                v.put("lot_size",num(p[4],1));v.put("lot_unit",p.length>7&&p[7].trim().length()>0?p[7].trim():"SHARE");v.put("quote_size",p.length>8?num(p[8],1):1);v.put("quote_unit",p.length>9&&p[9].trim().length()>0?p[9].trim():"SHARE");v.put("tick_size",num(p[5],0.01));
                v.put("lot_size_verified",0);v.put("active",1);v.put("source","BUNDLED");v.put("updated_at",now());
                db.insertWithOnConflict("contracts",null,v,SQLiteDatabase.CONFLICT_IGNORE);
            }
            db.setTransactionSuccessful();
        }catch(Exception ignored){}
        finally { if(inTx) { try { db.endTransaction(); } catch(Exception ignored){} } }
    }
    private double num(String s,double d){try{return Double.parseDouble(s.trim());}catch(Exception e){return d;}}
    private String now(){return new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());}

    public long addClient(String name,String code,String phone,String email){ContentValues v=new ContentValues();v.put("name",name);v.put("code",code);v.put("phone",phone);v.put("email",email);v.put("status","ACTIVE");return getWritableDatabase().insert("clients",null,v);}
    public long addSubBroker(String code,String name,String phone,String email,String address,String bank){ContentValues v=new ContentValues();v.put("code",code);v.put("name",name);v.put("phone",phone);v.put("email",email);v.put("address",address);v.put("bank_details",bank);v.put("status","ACTIVE");return getWritableDatabase().insert("sub_brokers",null,v);}
    public void setClientSubBroker(long client,long subBroker){ContentValues v=new ContentValues();if(subBroker>0)v.put("sub_broker_id",subBroker);else v.putNull("sub_broker_id");getWritableDatabase().update("clients",v,"id=?",new String[]{""+client});}
    public long clientSubBroker(long client){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(sub_broker_id,0) FROM clients WHERE id=?",new String[]{""+client});long x=0;if(c.moveToFirst())x=c.getLong(0);c.close();return x;}
    public String subBrokerName(long id){Cursor c=getReadableDatabase().rawQuery("SELECT name FROM sub_brokers WHERE id=?",new String[]{""+id});String n="";if(c.moveToFirst())n=c.getString(0);c.close();return n;}
    public String subBrokerCode(long id){Cursor c=getReadableDatabase().rawQuery("SELECT code FROM sub_brokers WHERE id=?",new String[]{""+id});String n="";if(c.moveToFirst())n=c.getString(0);c.close();return n;}
    public Cursor subBrokers(){return getReadableDatabase().rawQuery("SELECT id,code,name,phone,email,status FROM sub_brokers ORDER BY name",null);}
    public void setSubBrokerage(long client,long subBroker,String ex,String method,double rate,String effectiveFrom){ContentValues v=new ContentValues();v.put("client_id",client);v.put("sub_broker_id",subBroker);v.put("exchange_code",ex);v.put("method",method);v.put("rate",rate);v.put("effective_from",effectiveFrom);getWritableDatabase().insertWithOnConflict("sub_broker_brokerage",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public double getSubBrokerage(long client,String ex,double turnover,long lots){long sb=clientSubBroker(client);if(sb<=0)return 0;Cursor c=getReadableDatabase().rawQuery("SELECT method,rate FROM sub_broker_brokerage WHERE client_id=? AND exchange_code=?",new String[]{""+client,ex});double out=0;if(c.moveToFirst()){String m=c.getString(0);double r=c.getDouble(1);if("PER_CRORE".equals(m))out=turnover/10000000.0*r;else if("PERCENT".equals(m))out=turnover*r/100.0;else if("PER_LOT".equals(m))out=lots*r;}c.close();return out;}
    public Cursor clientsForSubBroker(long sb){return getReadableDatabase().rawQuery("SELECT id,name,code,status FROM clients WHERE sub_broker_id=? ORDER BY name",new String[]{""+sb});}
    public void setSubBrokerOpeningBalance(long sb,String date,double amount){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("opening_balance",amount);db.update("sub_brokers",v,"id=?",new String[]{""+sb});db.delete("sub_broker_ledger","sub_broker_id=? AND entry_type='OPENING'",new String[]{""+sb});addSubBrokerLedger(sb,date,"OPENING","Opening balance",amount<0?-amount:0,amount>0?amount:0,0);}
    public long addSubBrokerPayment(long sb,String date,double amount,String type,String ref,String remarks){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("sub_broker_id",sb);v.put("payment_date",date);v.put("amount",amount);v.put("payment_type",type);v.put("reference",ref);v.put("remarks",remarks);long id=db.insert("sub_broker_payments",null,v);addSubBrokerLedger(sb,date,"PAYMENT","Payment - "+type+(ref==null||ref.isEmpty()?"":" / "+ref),amount,0,id);return id;}
    public long addSubBrokerLedger(long sb,String date,String type,String desc,double debit,double credit,long ref){ContentValues v=new ContentValues();v.put("sub_broker_id",sb);v.put("entry_date",date);v.put("entry_type",type);v.put("description",desc);v.put("debit",debit);v.put("credit",credit);v.put("reference_id",ref);return getWritableDatabase().insert("sub_broker_ledger",null,v);}
    public double subBrokerBalance(long sb,String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(credit-debit),0) FROM sub_broker_ledger WHERE sub_broker_id=? AND entry_date<=?",new String[]{""+sb,date});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public Cursor subBrokerLedger(long sb,String from,String to){return getReadableDatabase().rawQuery("SELECT entry_date,entry_type,description,debit,credit FROM sub_broker_ledger WHERE sub_broker_id=? AND entry_date BETWEEN ? AND ? ORDER BY entry_date,id",new String[]{""+sb,from,to});}
    public Cursor subBrokerEarnings(long sb,String from,String to){return getReadableDatabase().rawQuery("SELECT e.earning_date,c.name,e.exchange_code,e.turnover,e.brokerage,e.earning,e.description FROM sub_broker_earnings e JOIN clients c ON c.id=e.client_id WHERE e.sub_broker_id=? AND e.earning_date BETWEEN ? AND ? ORDER BY e.earning_date,e.id",new String[]{""+sb,from,to});}
    public double subBrokerEarningsTotal(long sb,String from,String to){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(earning),0) FROM sub_broker_earnings WHERE sub_broker_id=? AND earning_date BETWEEN ? AND ?",new String[]{""+sb,from,to});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}

    public void setOpeningBalance(long client,String date,double amount){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("previous_balance",amount);v.put("opening_balance_date",date);db.update("clients",v,"id=?",new String[]{""+client});db.delete("ledger","client_id=? AND entry_type='OPENING'",new String[]{""+client});addLedger(client,date,"OPENING","Opening balance",amount>=0?amount:0,amount<0?-amount:0,0);}
    public long addPayment(long client,String date,double amount,String type,String ref,String remarks){SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("client_id",client);v.put("payment_date",date);v.put("amount",amount);v.put("payment_type",type);v.put("reference",ref);v.put("remarks",remarks);long id=db.insert("payments",null,v);addLedger(client,date,"PAYMENT","Payment - "+type+(ref==null||ref.isEmpty()?"":" / "+ref),0,amount,id);return id;}
    public long addLedger(long client,String date,String type,String desc,double debit,double credit,long ref){ContentValues v=new ContentValues();v.put("client_id",client);v.put("entry_date",date);v.put("entry_type",type);v.put("description",desc);v.put("debit",debit);v.put("credit",credit);v.put("reference_id",ref);return getWritableDatabase().insert("ledger",null,v);}
    public void setBrokerage(long client,String ex,String method,double rate){ContentValues v=new ContentValues();v.put("client_id",client);v.put("exchange_code",ex);v.put("method",method);v.put("rate",rate);getWritableDatabase().insertWithOnConflict("brokerage",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public boolean isLotVerified(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(lot_size_verified,0) FROM contracts WHERE id=?",new String[]{""+contract});boolean x=false;if(c.moveToFirst())x=c.getInt(0)==1;c.close();return x;}
    public double getLotSize(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT lot_size FROM contracts WHERE id=?",new String[]{""+contract});double x=1;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public String exchange(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT exchange_code FROM contracts WHERE id=?",new String[]{""+contract});String x="NSE";if(c.moveToFirst())x=c.getString(0);c.close();return x;}
    public String contractSymbol(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT symbol FROM contracts WHERE id=?",new String[]{""+contract});String x="";if(c.moveToFirst())x=c.getString(0);c.close();return x;}
    public double getBrokerage(long client,String ex,double turnover){Cursor c=getReadableDatabase().rawQuery("SELECT method,rate FROM brokerage WHERE client_id=? AND exchange_code=?",new String[]{""+client,ex});double out=0;if(c.moveToFirst()){String m=c.getString(0);double r=c.getDouble(1);if("PER_CRORE".equals(m))out=turnover/10000000.0*r;else if("PERCENT".equals(m))out=turnover*r/100.0;else if("PER_LOT".equals(m))out=r;}c.close();return out;}
    public long addTransaction(long client,long contract,String date,String side,double lots,double qty,double rate,String notes){SQLiteDatabase db=getWritableDatabase();double storedQty=qty>0?enteredQuantityToQuoteUnits(contract,qty):lotToQuoteUnits(contract,lots);double turnover=storedQty*rate;String ex=exchange(contract);double brok=getBrokerage(client,ex,turnover);long sb=clientSubBroker(client);double sbBrok=getSubBrokerage(client,ex,turnover,(long)Math.round(lots));ContentValues v=new ContentValues();v.put("client_id",client);v.put("contract_id",contract);v.put("trade_date",date);v.put("side",side);v.put("lots",lots);v.put("quantity",storedQty);v.put("rate",rate);v.put("turnover",turnover);v.put("brokerage",brok);if(sb>0)v.put("sub_broker_id",sb);else v.putNull("sub_broker_id");v.put("sub_brokerage",sbBrok);v.put("net_amount","BUY".equals(side)?-(turnover+brok):(turnover-brok));v.put("notes",notes);long id=db.insert("transactions",null,v);addLedger(client,date,"TRADE",side+" turnover / brokerage","BUY".equals(side)?turnover+brok:0,"SELL".equals(side)?turnover-brok:0,id);if(sb>0&&sbBrok>0){ContentValues e=new ContentValues();e.put("sub_broker_id",sb);e.put("client_id",client);e.put("transaction_id",id);e.put("earning_date",date);e.put("exchange_code",ex);e.put("turnover",turnover);e.put("brokerage",brok);e.put("earning",sbBrok);e.put("description","Sub-broker earning from "+side+" turnover");long eid=db.insert("sub_broker_earnings",null,e);addSubBrokerLedger(sb,date,"BROKERAGE_EARNED","Client "+client+" / "+ex+" / earning",0,sbBrok,eid);}return id;}
    private double unitFactor(String unit){if(unit==null)return 1;String u=unit.trim().toUpperCase(Locale.US);if(u.equals("GM")||u.equals("G")||u.equals("GRAM")||u.equals("GRAMS"))return 1;if(u.equals("KG")||u.equals("KGS")||u.equals("KILOGRAM")||u.equals("KILOGRAMS"))return 1000;if(u.equals("MG"))return 0.001;if(u.equals("MT")||u.equals("TON")||u.equals("TONNE")||u.equals("TONNES"))return 1000000;if(u.equals("SHARE")||u.equals("SHARES")||u.equals("UNIT")||u.equals("UNITS"))return 1;if(u.equals("BARREL")||u.equals("BARRELS"))return 1;return 1;}
    public double lotToQuoteUnits(long contract,double lots){double lot=getLotSize(contract);double qs=quoteSize(contract);double lf=unitFactor(lotUnit(contract));double qf=unitFactor(quoteUnit(contract));return lots*lot*lf/(qs*qf);}
    public double enteredQuantityToQuoteUnits(long contract,double qty){double qs=quoteSize(contract);double lf=unitFactor(lotUnit(contract));double qf=unitFactor(quoteUnit(contract));return qty*lf/(qs*qf);}
    public double quoteUnitsToLotUnits(long contract,double quoteUnits){double lot=getLotSize(contract);double qs=quoteSize(contract);double lf=unitFactor(lotUnit(contract));double qf=unitFactor(quoteUnit(contract));if(lot<=0||lf<=0)return quoteUnits*qf/lf;return quoteUnits*qs*qf/(lot*lf);}
    public double contractValue(long contract,double lots,double qty,double rate){double q=qty>0?enteredQuantityToQuoteUnits(contract,qty):lotToQuoteUnits(contract,lots);return q*rate;}
    public double quoteSize(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(quote_size,1) FROM contracts WHERE id=?",new String[]{""+contract});double x=1;if(c.moveToFirst())x=c.getDouble(0);c.close();return x<=0?1:x;}
    public String lotUnit(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(lot_unit,'UNIT') FROM contracts WHERE id=?",new String[]{""+contract});String x="UNIT";if(c.moveToFirst())x=c.getString(0);c.close();return x;}
    public String quoteUnit(long contract){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(quote_unit,'UNIT') FROM contracts WHERE id=?",new String[]{""+contract});String x="UNIT";if(c.moveToFirst())x=c.getString(0);c.close();return x;}
    public long addManualContract(String exchange,String symbol,String expiry,String instrument,double lot,String lotUnit,double quoteSize,String quoteUnit,double strike,String optionType){ContentValues v=new ContentValues();v.put("exchange_code",exchange);v.put("symbol",symbol);v.put("expiry",expiry);v.put("instrument_type",instrument);v.put("strike",strike);v.put("option_type",optionType);v.put("lot_size",lot);v.put("lot_unit",lotUnit);v.put("quote_size",quoteSize);v.put("quote_unit",quoteUnit);v.put("tick_size",0.01);v.put("lot_size_verified",0);v.put("active",1);v.put("source","MANUAL");v.put("updated_at",now());return getWritableDatabase().insertWithOnConflict("contracts",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public void updateTransaction(long id,long client,long contract,String date,String side,double lots,double qty,double rate,String notes){SQLiteDatabase w=getWritableDatabase();Cursor oldTx=w.rawQuery("SELECT client_id,contract_id FROM transactions WHERE id=?",new String[]{""+id});long oldClient=-1,oldContract=-1;if(oldTx.moveToFirst()){oldClient=oldTx.getLong(0);oldContract=oldTx.getLong(1);}oldTx.close();if(oldClient>0&&oldContract>0){w.delete("daily_mtm","client_id=? AND contract_id=?",new String[]{""+oldClient,""+oldContract});w.delete("weekly_settlements","client_id=? AND contract_id=?",new String[]{""+oldClient,""+oldContract});}w.delete("daily_mtm","client_id=? AND contract_id=?",new String[]{""+client,""+contract});w.delete("weekly_settlements","client_id=? AND contract_id=?",new String[]{""+client,""+contract});w.delete("ledger","reference_id=? AND entry_type='TRADE'",new String[]{""+id});Cursor old=w.rawQuery("SELECT id FROM sub_broker_earnings WHERE transaction_id=?",new String[]{""+id});ArrayList<Long> earnIds=new ArrayList<>();while(old.moveToNext())earnIds.add(old.getLong(0));old.close();for(Long eid:earnIds)w.delete("sub_broker_ledger","reference_id=?",new String[]{""+eid});w.delete("sub_broker_earnings","transaction_id=?",new String[]{""+id});double storedQty=qty>0?enteredQuantityToQuoteUnits(contract,qty):lotToQuoteUnits(contract,lots);double turnover=storedQty*rate;String ex=exchange(contract);double brok=getBrokerage(client,ex,turnover);long sb=clientSubBroker(client);double sbBrok=getSubBrokerage(client,ex,turnover,(long)Math.round(lots));ContentValues v=new ContentValues();v.put("client_id",client);v.put("contract_id",contract);v.put("trade_date",date);v.put("side",side);v.put("lots",lots);v.put("quantity",storedQty);v.put("rate",rate);v.put("turnover",turnover);v.put("brokerage",brok);if(sb>0)v.put("sub_broker_id",sb);else v.putNull("sub_broker_id");v.put("sub_brokerage",sbBrok);v.put("net_amount","BUY".equals(side)?-(turnover+brok):(turnover-brok));v.put("notes",notes);w.update("transactions",v,"id=?",new String[]{""+id});addLedger(client,date,"TRADE",side+" turnover / brokerage","BUY".equals(side)?turnover+brok:0,"SELL".equals(side)?turnover-brok:0,id);if(sb>0&&sbBrok>0){ContentValues e=new ContentValues();e.put("sub_broker_id",sb);e.put("client_id",client);e.put("transaction_id",id);e.put("earning_date",date);e.put("exchange_code",ex);e.put("turnover",turnover);e.put("brokerage",brok);e.put("earning",sbBrok);e.put("description","Sub-broker earning from "+side+" turnover");long eid=w.insert("sub_broker_earnings",null,e);addSubBrokerLedger(sb,date,"BROKERAGE_EARNED","Client "+client+" / "+ex+" / earning",0,sbBrok,eid);}}

    public void upsertContract(String ex,String sym,String expiry,String instrument,double strike,String opt,double lot,double tick,String source,int verified){upsertContract(ex,sym,expiry,instrument,strike,opt,lot,"UNIT",1,"UNIT",tick,source,verified);}
    public void upsertContract(String ex,String sym,String expiry,String instrument,double strike,String opt,double lot,String lotUnit,double quoteSize,String quoteUnit,double tick,String source,int verified){ContentValues v=new ContentValues();v.put("exchange_code",ex);v.put("symbol",sym);v.put("expiry",expiry);v.put("instrument_type",instrument);v.put("strike",strike);v.put("option_type",opt);v.put("lot_size",lot);v.put("lot_unit",lotUnit);v.put("quote_size",quoteSize);v.put("quote_unit",quoteUnit);v.put("tick_size",tick);v.put("lot_size_verified",verified);v.put("active",1);v.put("source",source);v.put("updated_at",now());getWritableDatabase().insertWithOnConflict("contracts",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public long upsertPrice(long contract,String date,double open,double high,double low,double close,double prev,double vol,double oi,double settlement,String source){ContentValues v=new ContentValues();v.put("contract_id",contract);v.put("price_date",date);v.put("open",open);v.put("high",high);v.put("low",low);v.put("close",close);v.put("previous_close",prev);v.put("volume",vol);v.put("open_interest",oi);v.put("settlement",settlement);v.put("source",source);return getWritableDatabase().insertWithOnConflict("prices",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
    public long contractId(String ex,String sym,String expiry,String instrument,double strike,String opt){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM contracts WHERE exchange_code=? AND symbol=? AND expiry=? AND instrument_type=? AND strike=? AND option_type=?",new String[]{ex,sym,expiry,instrument,""+strike,opt==null?"":opt});long id=-1;if(c.moveToFirst())id=c.getLong(0);c.close();return id;}
    public Cursor clients(){return getReadableDatabase().rawQuery("SELECT id,name,code,phone,email,status,previous_balance,COALESCE(sub_broker_id,0) FROM clients ORDER BY name",null);}
    public Cursor contracts(){return getReadableDatabase().rawQuery("SELECT id,exchange_code,symbol,expiry,instrument_type,strike,option_type,lot_size,lot_size_verified,lot_unit,quote_size,quote_unit FROM contracts WHERE active=1 ORDER BY exchange_code,symbol,expiry,strike",null);}
    public Cursor transactions(long client,String from,String to){return getReadableDatabase().rawQuery("SELECT t.id,t.trade_date,c.exchange_code,c.symbol,c.expiry,c.instrument_type,c.strike,c.option_type,t.side,t.lots,t.quantity,t.rate,t.turnover,t.brokerage,t.sub_brokerage,t.net_amount FROM transactions t JOIN contracts c ON c.id=t.contract_id WHERE t.client_id=? AND t.trade_date BETWEEN ? AND ? ORDER BY t.trade_date,t.id",new String[]{""+client,from,to});}
    public Cursor transactionsForDate(String date){return getReadableDatabase().rawQuery("SELECT t.id,t.contract_id,cl.name,c.exchange_code,c.symbol,c.expiry,t.side,t.lots,t.quantity,t.rate,t.turnover FROM transactions t JOIN clients cl ON cl.id=t.client_id JOIN contracts c ON c.id=t.contract_id WHERE t.trade_date=? ORDER BY t.id DESC",new String[]{date});}
    public Cursor transactionById(long id){return getReadableDatabase().rawQuery("SELECT t.id,t.client_id,t.contract_id,t.trade_date,t.side,t.lots,t.quantity,t.rate,t.notes,c.exchange_code,c.symbol,c.expiry,c.instrument_type,c.strike,c.option_type,c.lot_size,c.lot_unit,c.quote_size,c.quote_unit FROM transactions t JOIN contracts c ON c.id=t.contract_id WHERE t.id=?",new String[]{""+id});}
    public Cursor report(long client,String from,String to){return transactions(client,from,to);}
    public Cursor payments(long client,String from,String to){return getReadableDatabase().rawQuery("SELECT payment_date,amount,payment_type,reference,remarks FROM payments WHERE client_id=? AND payment_date BETWEEN ? AND ? ORDER BY payment_date,id",new String[]{""+client,from,to});}
    public String clientName(long id){Cursor c=getReadableDatabase().rawQuery("SELECT name FROM clients WHERE id=?",new String[]{""+id});String n="Client";if(c.moveToFirst())n=c.getString(0);c.close();return n;}

    public double positionQty(long client,long contract,String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN side='BUY' THEN quantity ELSE -quantity END),0) FROM transactions WHERE client_id=? AND contract_id=? AND trade_date<=?",new String[]{""+client,""+contract,date});double q=0;if(c.moveToFirst())q=c.getDouble(0);c.close();return q;}
    public double weightedOpenPrice(long client,long contract,String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(CASE WHEN side='BUY' THEN quantity*rate ELSE 0 END),0),COALESCE(SUM(CASE WHEN side='SELL' THEN quantity*rate ELSE 0 END),0),COALESCE(SUM(CASE WHEN side='BUY' THEN quantity ELSE -quantity END),0) FROM transactions WHERE client_id=? AND contract_id=? AND trade_date<=?",new String[]{""+client,""+contract,date});double b=0,s=0,q=0;if(c.moveToFirst()){b=c.getDouble(0);s=c.getDouble(1);q=c.getDouble(2);}c.close();if(q>0)return (b-s)/q; if(q<0)return (b-s)/q; return 0;}
    public double getPrice(long contract,String date){Cursor c=getReadableDatabase().rawQuery("SELECT close FROM prices WHERE contract_id=? AND price_date=?",new String[]{""+contract,date});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double close(long contract,String date){Cursor c=getReadableDatabase().rawQuery("SELECT close FROM prices WHERE contract_id=? AND price_date=?",new String[]{""+contract,date});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public double priorBase(long client,long contract,String date){Cursor c=getReadableDatabase().rawQuery("SELECT close_price FROM daily_mtm WHERE client_id=? AND contract_id=? AND mtm_date<? ORDER BY mtm_date DESC LIMIT 1",new String[]{""+client,""+contract,date});if(c.moveToFirst()){double x=c.getDouble(0);c.close();return x;}c.close();Cursor s=getReadableDatabase().rawQuery("SELECT settlement_price FROM weekly_settlements WHERE client_id=? AND contract_id=? AND settlement_date<? ORDER BY settlement_date DESC LIMIT 1",new String[]{""+client,""+contract,date});if(s.moveToFirst()){double x=s.getDouble(0);s.close();return x;}s.close();return weightedOpenPrice(client,contract,date);}
    public double processDailyMtm(long client,String date){double total=0;Cursor c=getReadableDatabase().rawQuery("SELECT DISTINCT contract_id FROM transactions WHERE client_id=? AND trade_date<=?",new String[]{""+client,date});SQLiteDatabase w=getWritableDatabase();while(c.moveToNext()){long con=c.getLong(0);double q=positionQty(client,con,date);if(Math.abs(q)<0.000001)continue;double close=close(con,date);if(close==0)continue;double base=priorBase(client,con,date);double mtm=(close-base)*q;ContentValues v=new ContentValues();v.put("client_id",client);v.put("contract_id",con);v.put("mtm_date",date);v.put("base_price",base);v.put("close_price",close);v.put("quantity",q);v.put("mtm",mtm);w.insertWithOnConflict("daily_mtm",null,v,SQLiteDatabase.CONFLICT_REPLACE);total+=mtm;}c.close();return total;}
    public double settleWeek(long client,String date){double total=0;Cursor c=getReadableDatabase().rawQuery("SELECT DISTINCT contract_id FROM transactions WHERE client_id=? AND trade_date<=?",new String[]{""+client,date});while(c.moveToNext()){long con=c.getLong(0);double q=positionQty(client,con,date);if(Math.abs(q)<0.000001)continue;double px=close(con,date);if(px==0)continue;double base=priorBase(client,con,date);double mtm=(px-base)*q;ContentValues v=new ContentValues();v.put("client_id",client);v.put("contract_id",con);v.put("settlement_date",date);v.put("quantity",q);v.put("base_price",base);v.put("settlement_price",px);v.put("mtm",mtm);getWritableDatabase().insertWithOnConflict("weekly_settlements",null,v,SQLiteDatabase.CONFLICT_REPLACE);addLedger(client,date,"SETTLEMENT","Weekly settlement / contract "+con,mtm<0?-mtm:0,mtm>0?mtm:0,con);total+=mtm;}c.close();return total;}
    public double balance(long client,String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(debit-credit),0) FROM ledger WHERE client_id=? AND entry_date<=?",new String[]{""+client,date});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public Cursor ledger(long client,String from,String to){return getReadableDatabase().rawQuery("SELECT entry_date,entry_type,description,debit,credit FROM ledger WHERE client_id=? AND entry_date BETWEEN ? AND ? ORDER BY entry_date,id",new String[]{""+client,from,to});}
    public int contractCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM contracts",null);c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    public int priceCount(String date){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM prices WHERE price_date=?",new String[]{date});c.moveToFirst();int x=c.getInt(0);c.close();return x;}
    public String latestPriceDateBefore(String date){Cursor c=getReadableDatabase().rawQuery("SELECT MAX(price_date) FROM prices WHERE price_date<?",new String[]{date});String x="";if(c.moveToFirst()&&!c.isNull(0))x=c.getString(0);c.close();return x;}
    public double latestClose(long contract,String beforeDate){Cursor c=getReadableDatabase().rawQuery("SELECT close FROM prices WHERE contract_id=? AND price_date=(SELECT MAX(price_date) FROM prices WHERE contract_id=? AND price_date<?)",new String[]{""+contract,""+contract,beforeDate});double x=0;if(c.moveToFirst())x=c.getDouble(0);c.close();return x;}
    public String setting(String key){Cursor c=getReadableDatabase().rawQuery("SELECT value FROM app_settings WHERE key=?",new String[]{key});String x="";if(c.moveToFirst())x=c.getString(0);c.close();return x;}
    public void setting(String key,String value){ContentValues v=new ContentValues();v.put("key",key);v.put("value",value);getWritableDatabase().insertWithOnConflict("app_settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);}
}
