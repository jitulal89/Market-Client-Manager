package com.marketclientmanager.app;

import android.content.Context;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

/**
 * Market-data updater.
 *
 * Automatic mode uses public downloadable exchange files where a stable
 * endpoint is available. NSE UDiFF files are fetched directly from the NSE
 * archive. NCDEX is discovered from its public Common Files page. MCX is
 * first attempted from its public Bhav Copy page and then from a public
 * mirror that republishes the exchange EOD data when MCX's web page is
 * bot-gated. Manual URLs remain available as a fallback in Settings.
 */
public class PriceUpdateManager {
    private static final String UA = "Mozilla/5.0 (Android) AppleWebKit/537.36 MarketClientManager/2.1.8";

    public static AutoResult updateAutomatic(Context ctx, DatabaseHelper db) throws Exception {
        AutoResult out = new AutoResult();
        String requested = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        String[] exchanges = {"NSE", "MCX", "NCDEX"};
        for (String ex : exchanges) {
            boolean done = false;
            Exception last = null;
            for (int daysBack = 1; daysBack <= 10 && !done; daysBack++) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DAY_OF_YEAR, -daysBack);
                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
                try {
                    Result r;
                    if ("NSE".equals(ex)) r = updateNse(db, date);
                    else if ("MCX".equals(ex)) r = updateMcx(db, date);
                    else r = updateNcdex(db, date);
                    if (r.contracts > 0 || r.prices > 0) {
                        out.contracts += r.contracts;
                        out.prices += r.prices;
                        out.exchangeDates.put(ex, date);
                        out.exchangeMessages.put(ex, r.message());
                        done = true;
                    }
                } catch (Exception e) {
                    last = e;
                }
            }
            if (!done) {
                String manual = db.setting(ex + "_URL");
                if (manual != null && !manual.trim().isEmpty()) {
                    try {
                        String date = previousCandidateDate();
                        Result r = updateFromCsv(db, ex, manual.trim(), date);
                        if (r.contracts > 0 || r.prices > 0) {
                            out.contracts += r.contracts;
                            out.prices += r.prices;
                            out.exchangeDates.put(ex, date);
                            out.exchangeMessages.put(ex, "Manual configured source");
                            done = true;
                        }
                    } catch (Exception e) {
                        last = e;
                    }
                }
            }
            if (!done) out.exchangeMessages.put(ex, "Not updated" + (last == null ? "" : ": " + last.getMessage()));
        }
        db.cleanupInvalidNseContracts();
        if (out.contracts == 0 && out.prices == 0) {
            throw new Exception("Automatic market-data update did not load any rows.\n\n" + out.summary());
        }
        return out;
    }

    private static Result updateNse(DatabaseHelper db, String date) throws Exception {
        Result total = new Result();
        String ymd = date.replace("-", "");
        String ddmmyyyy = ymd.substring(6,8) + ymd.substring(4,6) + ymd.substring(0,4);
        // NSE: futures only. Do NOT import the CM security master because it contains
        // the entire cash-market universe. The app is for tradeable futures contracts.
        String[] urls = {
            // Current NSE UDiFF F&O final Bhavcopy. Try the public archive host
            // first, then the alternate archive host used by NSE.
            "https://archives.nseindia.com/content/fo/BhavCopy_NSE_FO_0_0_0_" + ymd + "_F_0000.csv.zip",
            "https://nsearchives.nseindia.com/content/fo/BhavCopy_NSE_FO_0_0_0_" + ymd + "_F_0000.csv.zip",
            "https://nsearchives.nseindia.com/content/fo/NSE_FO_contract_" + ddmmyyyy + ".csv.gz"
        };
        String[] segments = {"NSE","NSE"};
        for (int i=0;i<urls.length;i++) {
            try {
                Result r = updateFromCsv(db, segments[i], urls[i], date);
                total.contracts += r.contracts;
                total.prices += r.prices;
            } catch (Exception ignored) { }
        }
        if (total.contracts == 0 && total.prices == 0) throw new Exception("NSE files unavailable for " + date);
        total.message();
        return total;
    }

    private static Result updateMcx(DatabaseHelper db, String date) throws Exception {
        Result r = new Result();
        // Try the official public page first. Some MCX pages are bot-gated;
        // if no downloadable file is exposed, use the public EOD mirror.
        try {
            String page = fetchText("https://www.mcxindia.com/market-data/bhavcopy?slinkpage=y");
            String url = findDownload(page, "(?i)(?:href|src)\\s*=\\s*[\\\"']([^\\\"']*?(?:bhav|Bhav)[^\\\"']*)");
            if (url != null) {
                r = updateFromCsv(db, "MCX", resolve("https://www.mcxindia.com/market-data/bhavcopy?slinkpage=y", url), date);
                if (r.prices > 0 || r.contracts > 0) return r;
            }
        } catch (Exception ignored) { }
        // Public mirror of exchange EOD data; no broker credentials/API key.
        String mirror = "https://mtf.trading/api/v1/mcx?date=" + date + "&format=csv&limit=100000";
        r = updateFromCsv(db, "MCX", mirror, date);
        if (r.prices == 0 && r.contracts == 0) throw new Exception("MCX Bhav Copy unavailable for " + date);
        return r;
    }

    private static Result updateNcdex(DatabaseHelper db, String date) throws Exception {
        String ymd = date.replace("-", "");
        String filename = "BhavCopy_NCD_CO_0_0_0_" + ymd + "_F_0000.csv";
        Exception last = null;

        // NCDEX moved its public EOD Bhavcopy to the UDiFF format. The exchange
        // Common Files portal publishes the exact filename, but its landing page
        // has changed over time. Try the landing page and the public Bhavcopy page
        // before falling back to known public download path variants.
        String[] pages={
            "https://common.ncdex.com/",
            "https://common.ncdex.com/Bhavcopy.aspx",
            "https://common.ncdex.com/BhavCopy.aspx",
            "https://www.ncdex.com/markets/bhavcopy"
        };
        for(String pageUrl:pages){
            try{
                String page=fetchText(pageUrl);
                String url=findDownload(page,"(?i)(?:href|src)\\s*=\\s*[\"']([^\"']*"+Pattern.quote(filename)+"[^\"']*)");
                if(url==null) url=findDownload(page,"(?i)(?:href|src)\\s*=\\s*[\"']([^\"']*BhavCopy_NCD_CO_0_0_0_[^\"']*\\.csv(?:\\?[^\"']*)?)");
                if(url!=null){
                    Result r=updateFromCsv(db,"NCDEX",resolve(pageUrl,url),date);
                    if(r.prices>0||r.contracts>0)return r;
                }
            }catch(Exception e){last=e;}
        }
        // Direct public paths used by the Common Files portal in different
        // deployments. These are tried only for the exact UDiFF filename.
        String[] direct={
            "https://common.ncdex.com/Bhavcopy/"+filename,
            "https://common.ncdex.com/BhavCopy/"+filename,
            "https://common.ncdex.com/Common/Bhavcopy/"+filename,
            "https://common.ncdex.com/Common/BhavCopy/"+filename
        };
        for(String url:direct){
            try{
                Result r=updateFromCsv(db,"NCDEX",url,date);
                if(r.prices>0||r.contracts>0)return r;
            }catch(Exception e){last=e;}
        }
        throw new Exception("NCDEX UDiFF Bhavcopy unavailable for "+date+(last==null?"":" ("+last.getMessage()+")"));
    }

    private static String previousCandidateDate() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -1);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    public static Result updateFromCsv(DatabaseHelper db,String exchange,String url,String date)throws Exception{
        URL u=new URL(url);URLConnection con=u.openConnection();con.setConnectTimeout(8000);con.setReadTimeout(20000);con.setRequestProperty("User-Agent",UA);con.setRequestProperty("Accept","*/*");
        InputStream raw=con.getInputStream();String lower=url.toLowerCase(Locale.US);Result total=new Result();
        if(lower.contains(".zip")){
            ZipInputStream zin=new ZipInputStream(raw);ZipEntry e;
            while((e=zin.getNextEntry())!=null){if(e.isDirectory())continue;String n=e.getName().toLowerCase(Locale.US);if(!(n.endsWith(".csv")||n.endsWith(".txt")||n.endsWith(".dat")))continue;Result r=parseStream(db,exchange,zin,date);total.contracts+=r.contracts;total.prices+=r.prices;}
            zin.close();
        }else{
            if(lower.contains(".gz"))raw=new GZIPInputStream(raw);
            Result r=parseStream(db,exchange,raw,date);total.contracts+=r.contracts;total.prices+=r.prices;raw.close();
        }
        return total;
    }

    private static Result parseStream(DatabaseHelper db,String exchange,InputStream in,String date)throws Exception{
        BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));String header=br.readLine();if(header==null)return new Result();
        String[] h=parseCsv(header);Map<String,Integer> idx=new HashMap<>();for(int i=0;i<h.length;i++)idx.put(clean(h[i]),i);
        Result result=new Result();String line;
        while((line=br.readLine())!=null){String[] p=parseCsv(line);if(p.length<3)continue;
            // UDiFF can contain an exchange instrument identifier as the first
            // symbol-like field. For NSE futures we must use the UNDERLYING/ticker
            // symbol (e.g. DMART), not identifiers such as 673HPC30/672TR40.
            String sym;
            if("NSE".equals(exchange)){
                // Current NSE UDiFF F&O uses TckrSymb as the actual trading symbol.
                // Do not use CM/security identifiers or generic instrument names here.
                sym=get(p,idx,"TCKRSYMB");
            }else{
                sym=get(p,idx,"SYMBOL","TCKRSYMB","SYMBOLNAME","CONTRACT","UNDERLYINGSYMBOL","COMMODITY","FININSTRMNM");
            }
            // UDiFF XpryDt / FininstrmActlXpryDt are YYYY-MM-DD. Prefer the
            // actual expiry field and normalize other legacy representations.
            String expiry=get(p,idx,"FININSTRMACTLXPRYDT","XPRYDT","EXPIRY","EXPIRYDATE","EXPIRY_DT");
            expiry=normalizeExpiry(expiry);
            String inst=get(p,idx,"INSTRUMENT","INSTRUMENTTYPE","FININSTRMTP","INSTRUMENT_TYPE","INSTRUMENTNAME");
            String opt=get(p,idx,"OPTIONTYPE","OPTNTP","OPTION_TYPE");
            double strike=num(get(p,idx,"STRIKE","STRIKEPRICE","STRKPRIC"),0);
            // Futures/equity only. Never import Call/Put option rows.
            String instForFilter=inst==null?"":inst.trim().toUpperCase(Locale.US);
            String optForFilter=opt==null?"":opt.trim().toUpperCase(Locale.US);
            boolean isOption = "CE".equals(optForFilter) || "PE".equals(optForFilter)
                    || instForFilter.contains("OPTION")
                    || instForFilter.contains("OPTIDX")
                    || instForFilter.contains("OPTSTK")
                    || (instForFilter.contains("OPT") && (instForFilter.contains("IDX") || instForFilter.contains("STK")));
            if(isOption) continue;
            String lotRaw=get(p,idx,"LOTSIZE","LOT_SIZE","CONTRACTSIZE","NEWBRDLOTQTY","TRADINGUNIT","TRADEUNIT","UNITOFMEASURE");
            double lot=num(lotRaw,1);
            String lotUnit=get(p,idx,"LOTUNIT","LOT_UNIT","QUANTITYUNIT","QTYUNIT","MEASURE","MEASUREUNIT","UNITOFMEASURE");
            // Some exchange files put both the number and unit in one field, e.g.
            // "1000 KGS". Parse that instead of silently falling back to lot=1.
            if(lotRaw!=null){
                Matcher lm=Pattern.compile("(?i)^\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([A-Z]+(?:\\s*[A-Z]+)?)\\s*$").matcher(lotRaw.trim());
                if(lm.matches()){ lot=num(lm.group(1),lot); if(lotUnit==null||lotUnit.trim().isEmpty()||lotUnit.equalsIgnoreCase(lotRaw.trim())) lotUnit=lm.group(2).trim(); }
            }
            double tick=num(get(p,idx,"TICKSIZE","TICK_SIZE"),0.01);
            String quoteUnit=get(p,idx,"QUOTEUNIT","QUOTE_UNIT","PRICEUNIT","PRCUNIT","PRICEQUOTEUNIT");
            String quoteSizeRaw=get(p,idx,"QUOTESIZE","QUOTE_SIZE","PRICESIZE","PRICEUNITVALUE");
            double quoteSize=num(quoteSizeRaw,1);
            if(lotUnit==null||lotUnit.isEmpty())lotUnit=exchange.equals("NSE")?"SHARE":"UNIT";
            if(quoteUnit==null||quoteUnit.isEmpty())quoteUnit=lotUnit;
            if(exchange.equals("MCX")){
                String mcxSym=sym==null?"":sym.trim().toUpperCase(Locale.US);
                McxSpec spec=mcxSpec(mcxSym);
                if(spec!=null){lot=spec.lot;lotUnit=spec.lotUnit;quoteSize=spec.quoteSize;quoteUnit=spec.quoteUnit;}
            }
            double open=num(get(p,idx,"OPEN","OPENPRICE","OPNPRIC","OPENINGPRICE"),0);
            double high=num(get(p,idx,"HIGH","HIGHPRICE","HGHPRIC"),0);
            double low=num(get(p,idx,"LOW","LOWPRICE","LWPRIC"),0);
            double close=num(get(p,idx,"CLOSE","CLOSINGPRICE","CLSPRC","CLSPRIC"),0);
            double prev=num(get(p,idx,"PREVCLOSE","PREVIOUSCLOSE","PRVSCLSGPRIC","PRVCLS","PREVIOUSCLOSINGPRICE"),0);
            double vol=num(get(p,idx,"VOLUME","TRADEQUANTITY","TRADGVOL","TTLTRADGVOL","VOL","QUANTITYTRADEDTODAY"),0);
            double oi=num(get(p,idx,"OI","OPENINTEREST","OPNINTRST","OPNINTRSTQTY"),0);
            double sett=num(get(p,idx,"SETTLEMENT","SETTLEMENTPRICE","STTLMTPRC","STTLMPRIC","STTLPRIC","SETLPRIC"),close);
            if(sym==null||sym.trim().isEmpty())continue;
            String symCheck=sym.trim().toUpperCase(Locale.US);
            if("NSE".equals(exchange) && symCheck.contains("NSETEST")) continue;
            if(expiry==null||expiry.trim().isEmpty())continue;
            if(!isValidExpiryForImport(expiry))continue;
            String rawInstrument=inst==null?"":inst.trim().toUpperCase(Locale.US);
            String option=opt==null?"":opt.trim().toUpperCase(Locale.US);
            String combined=(rawInstrument+" "+sym+" "+option).toUpperCase(Locale.US);
            if(combined.matches(".*\\b(CE|PE)\\b.*") || combined.contains("OPTION") || rawInstrument.contains("OPTIDX") || rawInstrument.contains("OPTSTK")) continue;
            // Keep only actual futures for NSE. Cash-market/security-master rows are ignored.
            String instrument;
            if("NSE".equals(exchange)){
                // UDiFF uses STF = Stock Futures and IDF = Index Futures.
                // Older/legacy files used FUTSTK/FUTIDX/FUTURE. Support both.
                if(rawInstrument.equals("STF") || rawInstrument.contains("FUTSTK")) instrument="FUTSTK";
                else if(rawInstrument.equals("IDF") || rawInstrument.contains("FUTIDX")) instrument="FUTIDX";
                else if(rawInstrument.equals("FUTURE")) instrument="FUTURE";
                else continue;
            } else if("NCDEX".equals(exchange)){
                // NCDEX UDiFF: COF = Futures Commodity, IDF = Index Futures.
                if(rawInstrument.equals("COF")) instrument="FUTURE";
                else if(rawInstrument.equals("IDF")) instrument="FUTIDX";
                else if(rawInstrument.equals("FUTURE") || rawInstrument.contains("FUT")) instrument="FUTURE";
                else continue;
            } else {
                instrument="FUTURE";
            }
            db.upsertContract(exchange,sym.trim(),expiry.trim(),instrument,0,"",lot,lotUnit,quoteSize,quoteUnit,tick,exchange+"_AUTO",1);
            long cid=db.contractId(exchange,sym.trim(),expiry.trim(),instrument,0,"");if(cid<0)continue;result.contracts++;
            if(close!=0||prev!=0){if(close==0)close=prev;db.upsertPrice(cid,date,open,high,low,close,prev,vol,oi,sett,exchange+"_AUTO");result.prices++;}
        }
        return result;
    }

    static String normalizeExpiry(String x){
        if(x==null)return "";
        String v=x.replace("\"","").trim().toUpperCase(Locale.US);
        if(v.isEmpty())return "";
        // Current UDiFF: YYYY-MM-DD. Keep it canonical.
        if(v.matches("\\d{4}-\\d{2}-\\d{2}"))return v;
        String[] formats={"dd-MMM-yyyy","ddMMMyyyy","dd-MMM-yy","ddMMMyy","dd/MM/yyyy","ddMMyyyy"};
        for(String f:formats){try{SimpleDateFormat in=new SimpleDateFormat(f,Locale.US);in.setLenient(false);Date d=in.parse(v);if(d!=null)return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);}catch(Exception ignored){}}
        return "";
    }
    static boolean isValidExpiryForImport(String x){
        try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);Date d=f.parse(x);Calendar c=Calendar.getInstance();c.setTime(d);int y=c.get(Calendar.YEAR);return y>=2024&&y<=2100;}catch(Exception e){return false;}
    }

    static class McxSpec{double lot;String lotUnit;double quoteSize;String quoteUnit;McxSpec(double l,String lu,double q,String qu){lot=l;lotUnit=lu;quoteSize=q;quoteUnit=qu;}}
    static McxSpec mcxSpec(String sym){
        if(sym==null)return null;
        String s=sym.trim().toUpperCase(Locale.US);
        if("GOLD".equals(s))return new McxSpec(1,"KG",10,"GM");
        if("GOLDM".equals(s))return new McxSpec(100,"GM",10,"GM");
        if("GOLDTEN".equals(s))return new McxSpec(10,"GM",10,"GM");
        if("GOLDGUINEA".equals(s))return new McxSpec(8,"GM",8,"GM");
        if("GOLDPETAL".equals(s))return new McxSpec(1,"GM",1,"GM");
        if("SILVER".equals(s))return new McxSpec(30,"KG",1,"KG");
        if("SILVERM".equals(s))return new McxSpec(5,"KG",1,"KG");
        if("SILVERMIC".equals(s))return new McxSpec(1,"KG",1,"KG");
        if("SILVER100".equals(s))return new McxSpec(100,"GM",100,"GM");
        if("COPPER".equals(s))return new McxSpec(2500,"KG",1,"KG");
        if("ALUMINIUM".equals(s))return new McxSpec(5000,"KG",1,"KG");
        if("ALUMINI".equals(s))return new McxSpec(1000,"KG",1,"KG");
        if("LEAD".equals(s))return new McxSpec(5000,"KG",1,"KG");
        if("LEADMINI".equals(s))return new McxSpec(1000,"KG",1,"KG");
        if("NICKEL".equals(s))return new McxSpec(1500,"KG",1,"KG");
        if("ZINC".equals(s))return new McxSpec(5000,"KG",1,"KG");
        if("ZINCMINI".equals(s))return new McxSpec(1000,"KG",1,"KG");
        if("CRUDEOIL".equals(s))return new McxSpec(100,"BARREL",1,"BARREL");
        if("CRUDEOILM".equals(s))return new McxSpec(10,"BARREL",1,"BARREL");
        if("NATURALGAS".equals(s))return new McxSpec(1250,"MMBTU",1,"MMBTU");
        if("NATGASMINI".equals(s))return new McxSpec(250,"MMBTU",1,"MMBTU");
        if("CARDAMOM".equals(s))return new McxSpec(100,"KG",1,"KG");
        if("COTTON".equals(s))return new McxSpec(25,"BALE",1,"BALE");
        if("COTTONOIL".equals(s))return new McxSpec(5000,"KG",10,"KG");
        if("MENTHAOIL".equals(s))return new McxSpec(360,"KG",1,"KG");
        if("CPO".equals(s))return new McxSpec(10000,"KG",10,"KG");
        if("KAPAS".equals(s))return new McxSpec(4000,"KG",20,"KG");
        return null;
    }

    static class Result{int contracts;int prices;String message(){return contracts+" contracts / "+prices+" prices";}}
    public static class AutoResult{
        public int contracts,prices; public Map<String,String> exchangeDates=new LinkedHashMap<>(); public Map<String,String> exchangeMessages=new LinkedHashMap<>();
        public String summary(){StringBuilder s=new StringBuilder();for(String ex:new String[]{"NSE","MCX","NCDEX"})s.append(ex).append(": ").append(exchangeMessages.get(ex)==null?"Not updated":exchangeMessages.get(ex)).append(exchangeDates.get(ex)==null?"":" ["+exchangeDates.get(ex)+"]").append("\n");return s.toString().trim();}
    }
    static String clean(String s){return s==null?"":s.replace("\uFEFF","").replace("\"","").trim().toUpperCase(Locale.US).replace(" ","").replace("_","");}
    static String get(String[] p,Map<String,Integer> idx,String... keys){for(String k:keys){Integer i=idx.get(clean(k));if(i!=null&&i<p.length)return p[i].replace("\"","").trim();}return null;}
    static double num(String s,double d){try{return Double.parseDouble(s==null?"":s.replace(",","").trim());}catch(Exception e){return d;}}
    static String[] parseCsv(String line){List<String> out=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<line.length();i++){char c=line.charAt(i);if(c=='\"'){q=!q;}else if(c==','&&!q){out.add(b.toString());b.setLength(0);}else b.append(c);}out.add(b.toString());return out.toArray(new String[0]);}
    static String fetchText(String url)throws Exception{URLConnection c=new URL(url).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent",UA);c.setRequestProperty("Accept","text/html,*/*");InputStream in=c.getInputStream();BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line).append('\n');br.close();return s.toString();}
    static String findDownload(String html,String regex){Matcher m=Pattern.compile(regex).matcher(html);return m.find()?m.group(1):null;}
    static String resolve(String base,String href)throws Exception{return new URL(new URL(base),href).toString();}
    public static int updateCsv(Context ctx,DatabaseHelper db,String url,String date)throws Exception{return updateFromCsv(db,"NSE",url,date).prices;}
}
