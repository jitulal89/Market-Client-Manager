# v2.1.6 - Futures-only market master and UI cleanup

This release addresses the market-data problems seen in v2.1.5:

- NSE cash-market security master is no longer imported into the trade-entry universe.
- NSE Trade Entry shows only futures (FUTSTK/FUTIDX) with an expiry.
- Options (CE/PE) are excluded.
- Duplicate expiry rows are collapsed to one contract per symbol/expiry in the UI.
- Expiries are shown in chronological order.
- MCX ALUMINI is treated as 1,000 KG per lot and quoted per KG.
- MCX ALUMINIUM is treated as 5,000 KG per lot and quoted per KG.
- Lot fields such as `1000 KGS` are parsed correctly instead of becoming lot size 1.
- Existing database records are retained; non-futures NSE rows are simply not offered for new trade entry.
- Spinner typography and padding are improved.

The GitHub Actions workflow intentionally hardcodes `MarketClientManager_v2.1.6.zip`.
