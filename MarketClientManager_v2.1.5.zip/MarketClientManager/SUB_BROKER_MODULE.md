# Sub Broker / Referral Partner Module — v2.1

## Workflow

1. Register a person/company as a **Sub Broker / Referral Partner** with a unique code.
2. During client registration, select **Referred By / Sub Broker**.
3. Define client brokerage and the Sub Broker share for NSE, MCX and NCDEX.
4. Save client trades. The app calculates client brokerage and the configured Sub Broker earning automatically.
5. Each Sub Broker earning is posted to a separate Sub Broker ledger.
6. Record payments made to the Sub Broker; payments reduce the Sub Broker outstanding balance.
7. View referred clients, earnings, ledger, payments and outstanding balance.
8. Client and Sub Broker accounts remain separate.

## Database additions

- `sub_brokers`
- `sub_broker_brokerage`
- `sub_broker_earnings`
- `sub_broker_payments`
- `sub_broker_ledger`
- `clients.sub_broker_id`
- `transactions.sub_broker_id`
- `transactions.sub_brokerage`

## Accounting example

Client brokerage: ₹3,000 per ₹1 crore.

Sub Broker share: ₹1,000 per ₹1 crore.

At ₹2 crore eligible turnover:

- Client brokerage = ₹6,000
- Sub Broker earning = ₹2,000
- If ₹1,500 is subsequently paid to the Sub Broker, ₹500 remains outstanding.

The client trading balance is not reduced by the Sub Broker payment.

## Migration

Database version is upgraded from 5 to 6. Existing client/trade/market data is preserved. New Sub Broker tables and columns are created during SQLite upgrade.
