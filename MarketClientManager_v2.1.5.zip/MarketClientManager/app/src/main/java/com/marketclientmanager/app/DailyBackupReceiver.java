package com.marketclientmanager.app;
import android.content.*;
public class DailyBackupReceiver extends BroadcastReceiver{
 @Override public void onReceive(Context c,Intent i){try{BackupManager.backup(c);}catch(Exception ignored){}}
}
