package com.marketclientmanager.app;
import android.content.*;import android.database.*;import android.graphics.*;import android.graphics.pdf.PdfDocument;import java.io.*;import java.util.*;
public class PdfReportGenerator{
 public static File generate(Context ctx,DatabaseHelper db,long client,String from,String to)throws Exception{
  PdfDocument doc=new PdfDocument();PdfDocument.Page page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();Paint p=new Paint();p.setColor(Color.BLACK);p.setTextSize(16);float y=35;int pageNo=1;
  c.drawText(db.clientName(client),35,y,p);y+=20;p.setTextSize(10);c.drawText("Account Statement  From "+from+" To "+to,35,y,p);y+=16;long sb=db.clientSubBroker(client);c.drawText("Sub Broker: "+(sb>0?db.subBrokerName(sb)+" ["+db.subBrokerCode(sb)+"]":"Direct / None"),35,y,p);y+=22;
  Cursor r=db.report(client,from,to);double gross=0,brok=0,subBrok=0,net=0;
  while(r.moveToNext()){
   if(y>790){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();y=35;}
   p.setTextSize(8);String line=r.getString(1)+" | "+r.getString(2)+" "+r.getString(3)+" | "+r.getString(8)+" | Qty "+r.getDouble(10)+" | Rate "+r.getDouble(11)+" | Turnover "+String.format(Locale.US,"%.2f",r.getDouble(12))+" | Brokerage "+String.format(Locale.US,"%.2f",r.getDouble(13))+" | SB "+String.format(Locale.US,"%.2f",r.getDouble(14));c.drawText(line,25,y,p);y+=14;gross+=r.getDouble(12);brok+=r.getDouble(13);subBrok+=r.getDouble(14);net+=r.getDouble(15);
  }r.close();
  if(y>730){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();y=35;}
  y+=12;p.setTextSize(11);c.drawText("Gross Turnover: "+String.format(Locale.US,"%.2f",gross),35,y,p);y+=18;c.drawText("Client Brokerage: "+String.format(Locale.US,"%.2f",brok),35,y,p);y+=18;c.drawText("Sub Broker Earned: "+String.format(Locale.US,"%.2f",subBrok),35,y,p);y+=18;c.drawText("Trading Net: "+String.format(Locale.US,"%.2f",net),35,y,p);y+=22;c.drawText("Client Balance: "+String.format(Locale.US,"%.2f",db.balance(client,to)),35,y,p);y+=20;
  Cursor l=db.ledger(client,from,to);p.setTextSize(10);c.drawText("Client Ledger",35,y,p);y+=16;while(l.moveToNext()){if(y>790){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();y=35;}c.drawText(l.getString(0)+"  "+l.getString(1)+"  Dr "+String.format(Locale.US,"%.2f",l.getDouble(3))+"  Cr "+String.format(Locale.US,"%.2f",l.getDouble(4)),35,y,p);y+=13;}l.close();
  if(sb>0){if(y>740){doc.finishPage(page);page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++pageNo).create());c=page.getCanvas();y=35;}y+=15;p.setTextSize(10);c.drawText("Sub Broker Period Earnings: "+String.format(Locale.US,"%.2f",db.subBrokerEarningsTotal(sb,from,to)),35,y,p);y+=16;c.drawText("Sub Broker Outstanding: "+String.format(Locale.US,"%.2f",db.subBrokerBalance(sb,to)),35,y,p);}
  doc.finishPage(page);File f=new File(ctx.getExternalFilesDir(null),"Report_"+db.clientName(client).replaceAll("[^A-Za-z0-9]","_")+"_"+from+"_"+to+".pdf");try(FileOutputStream out=new FileOutputStream(f)){doc.writeTo(out);}doc.close();return f;
 }
}
