package com.marketclientmanager.app;
import android.content.*;import androidx.core.content.FileProvider;import android.net.Uri;import java.io.*;import java.text.*;import java.util.*;
public class BackupManager{
 static File dir(Context c){File d=new File(c.getExternalFilesDir(null),"Backups");if(!d.exists())d.mkdirs();return d;}
 static File latest(Context c){return new File(dir(c),"MarketClient_Backup_Latest.dbbackup");}
 static File backup(Context c)throws Exception{DatabaseHelper h=new DatabaseHelper(c);h.close();File src=c.getDatabasePath(DatabaseHelper.DB_NAME);if(!src.exists())throw new Exception("Database not found");String ts=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());File out=new File(dir(c),"MarketClient_Backup_"+ts+".dbbackup");copy(src,out);copy(out,latest(c));prune(c,30);return out;}
 static void prune(Context c,int keep){File[] fs=dir(c).listFiles((d,n)->n.endsWith(".dbbackup")&&!n.contains("Latest"));if(fs==null||fs.length<=keep)return;Arrays.sort(fs,Comparator.comparingLong(File::lastModified));for(int i=0;i<fs.length-keep;i++)fs[i].delete();}
 static void copy(File a,File b)throws Exception{try(InputStream i=new FileInputStream(a);OutputStream o=new FileOutputStream(b)){byte[] buf=new byte[16384];int n;while((n=i.read(buf))>0)o.write(buf,0,n);}}
 static void restore(Context c,Uri uri)throws Exception{DatabaseHelper h=new DatabaseHelper(c);h.close();File db=c.getDatabasePath(DatabaseHelper.DB_NAME);if(db.exists())copy(db,new File(dir(c),"PreRestore_"+System.currentTimeMillis()+".dbbackup"));File tmp=new File(dir(c),"restore.tmp");try(InputStream i=c.getContentResolver().openInputStream(uri);OutputStream o=new FileOutputStream(tmp)){byte[] b=new byte[16384];int n;while((n=i.read(b))>0)o.write(b,0,n);}if(tmp.length()<1024)throw new Exception("Backup file appears invalid");if(db.exists())db.delete();copy(tmp,db);tmp.delete();}
 static Intent share(Context c,File f){Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_STREAM,FileProvider.getUriForFile(c,c.getPackageName()+".backup",f));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);return i;}
 static File[] history(Context c){File[] fs=dir(c).listFiles((d,n)->n.endsWith(".dbbackup"));if(fs==null)return new File[0];Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));return fs;}
}
