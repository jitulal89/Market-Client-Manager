package com.marketclientmanager.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.text.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DatabaseHelper db; LinearLayout root; final int PAD=18; ArrayList<Long> ids=new ArrayList<>();
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        showStartupMessage("Starting Market Client Manager…");
        try {
            initializeDatabase();
            try { scheduleBackup(); } catch (Throwable ignored) { }
            home();
        } catch (Throwable e) {
            showStartupError(e);
        }
    }

    private void initializeDatabase() {
        if (db != null) { try { db.close(); } catch (Exception ignored) { } }
        db = new DatabaseHelper(getApplicationContext());
        db.seed();
        // Touch the database after seeding so a partially initialized database
        // fails here with a useful diagnostic instead of crashing later in home().
        db.contractCount();
        db.priceCount(today());
    }

    private void showStartupMessage(String message) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(PAD, PAD, PAD, PAD);
        TextView t = new TextView(this);
        t.setText(message);
        t.setTextSize(20);
        l.addView(t);
        setContentView(l);
    }

    private void showStartupError(Throwable error) {
        String msg = error == null ? "Unknown startup error" : error.toString();
        if (error != null && error.getCause() != null) msg += "\nCause: " + error.getCause();
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(PAD, PAD, PAD, PAD);
        TextView title = new TextView(this);
        title.setText("Market Client Manager could not start");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(183, 28, 28));
        l.addView(title);
        TextView detail = new TextView(this);
        detail.setText("The app detected a local database/startup problem.\n\n" + msg);
        detail.setTextIsSelectable(true);
        detail.setPadding(0, PAD, 0, PAD);
        l.addView(detail);
        Button retry = btn("Retry");
        retry.setOnClickListener(v -> {
            try {
                showStartupMessage("Starting Market Client Manager…");
                initializeDatabase();
                try { scheduleBackup(); } catch (Throwable ignored) { }
                home();
            } catch (Throwable e) {
                showStartupError(e);
            }
        });
        l.addView(retry);
        setContentView(l);
    }
    void scheduleBackup(){AlarmManager a=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,DailyBackupReceiver.class);PendingIntent p=PendingIntent.getBroadcast(this,77,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,20);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);a.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,p);}
    int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    GradientDrawable bg(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)radius));return g;}
    TextView title(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(24);t.setTypeface(null,1);t.setTextColor(Color.rgb(17,38,63));t.setPadding(dp(20),dp(18),dp(20),dp(6));return t;}
    TextView info(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(14);t.setTextColor(Color.rgb(75,91,110));t.setPadding(dp(16),dp(12),dp(16),dp(12));t.setBackground(bg(Color.WHITE,14));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(Color.rgb(18,52,86));b.setMinHeight(dp(50));b.setPadding(dp(14),dp(8),dp(14),dp(8));b.setBackground(bg(Color.WHITE,14));return b;}
    EditText edit(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(15);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setMinHeight(dp(52));e.setBackground(bg(Color.WHITE,12));return e;}
    TextView section(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(13);t.setTypeface(null,1);t.setTextColor(Color.rgb(21,101,192));t.setPadding(dp(4),dp(16),dp(4),dp(7));return t;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(12),dp(14),dp(12));c.setBackground(bg(Color.WHITE,16));return c;}
    void addCard(LinearLayout c){root.addView(c,new LinearLayout.LayoutParams(-1,-2));}
    void addGap(int h){Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(h)));}
    void base(String name){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),0,dp(10),dp(20));root.setBackgroundColor(Color.rgb(244,247,251));ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(root);setContentView(sc);LinearLayout head=card();TextView t=title(name);head.addView(t);TextView sub=new TextView(this);sub.setText("Market Client Manager • Offline first");sub.setTextSize(12);sub.setTextColor(Color.rgb(100,116,135));sub.setPadding(dp(20),0,dp(20),dp(12));head.addView(sub);addCard(head);addGap(8);}
    void home(){base("Market Client Manager");LinearLayout hero=card();TextView h=new TextView(this);h.setText("Trading Desk");h.setTextSize(18);h.setTypeface(null,1);h.setTextColor(Color.rgb(17,38,63));hero.addView(h);TextView x=new TextView(this);x.setText("Clients, trades, expiry contracts, closing prices, MTM, brokerage and settlements in one place.");x.setTextSize(14);x.setTextColor(Color.rgb(75,91,110));x.setPadding(0,dp(5),0,dp(8));hero.addView(x);TextView stats=new TextView(this);stats.setText("Contracts  "+db.contractCount()+"     •     Prices today  "+db.priceCount(today())+"     •     Latest close  "+(db.latestPriceDateBefore(today()).isEmpty()?"Not loaded":db.latestPriceDateBefore(today())));stats.setTextSize(12);stats.setTextColor(Color.rgb(21,101,192));hero.addView(stats);addCard(hero);addGap(8);addCardButton("Daily Trade Entry","Enter BUY/SELL trades with exact expiry, lot size and value",v->trade());addCardButton("Market Data","Update contract master + previous trading-day closing prices",v->marketData());addCardButton("Clients","Manage clients, brokerage, sub-brokers and balances",v->clients());addCardButton("Daily MTM / Weekly Settlement","Process MTM and carry-forward settlement",v->settlement());addCardButton("Payments / Client Ledger","Payments, debit/credit ledger and balances",v->payments());addCardButton("Reports","Client, exchange and contract reports",v->reports());addCardButton("Sub Brokers / Referral Partners","Earnings, payments and outstanding balances",v->subBrokers());addCardButton("Backup & Restore","Local backup, restore and sharing",v->backup());addCardButton("Settings / Data Sources","Configure allowed CSV/Bhavcopy sources",v->settings());}
    void addCardButton(String name,String desc,View.OnClickListener l){LinearLayout c=card();TextView n=new TextView(this);n.setText(name);n.setTextSize(16);n.setTypeface(null,1);n.setTextColor(Color.rgb(18,52,86));c.addView(n);TextView d=new TextView(this);d.setText(desc);d.setTextSize(12);d.setTextColor(Color.rgb(100,116,135));d.setPadding(0,dp(4),0,dp(8));c.addView(d);Button b=btn("Open");b.setOnClickListener(l);c.addView(b);addCard(c);addGap(7);}
    Button addBtn(String s,View.OnClickListener l){Button b=btn(s);b.setOnClickListener(l);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(2),dp(4),dp(2),dp(4));root.addView(b,lp);return b;}

    void clients(){base("Clients");addBtn("+ Add Client",v->addClient());Cursor c=db.clients();while(c.moveToNext()){long id=c.getLong(0);long sb=c.getLong(7);String referral=sb>0?" | Sub Broker: "+db.subBrokerName(sb):" | No Sub Broker";String s=c.getString(1)+"  ["+c.getString(2)+"]  Balance: "+money(db.balance(id,today()))+referral;addBtn(s,v->clientDetail(id));}c.close();addBtn("Home",v->home());}

    void addClient(){base("Add Client");EditText n=edit("Client name *"),code=edit("Client code"),phone=edit("Phone"),email=edit("Email"),bal=edit("Opening balance (positive = Dr)");root.addView(n);root.addView(code);root.addView(phone);root.addView(email);
        Spinner sb=new Spinner(this);ArrayList<Long> sbIds=new ArrayList<>();ArrayList<String> sbNames=new ArrayList<>();sbIds.add(0L);sbNames.add("No Sub Broker / Direct Client");Cursor sc=db.subBrokers();while(sc.moveToNext()){sbIds.add(sc.getLong(0));sbNames.add(sc.getString(1)+" - "+sc.getString(2));}sc.close();sb.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,sbNames));root.addView(info("Referred By / Sub Broker"));root.addView(sb);
        EditText sbN=edit("NSE Sub Broker share per crore (₹)"),sbM=edit("MCX Sub Broker share per crore (₹)"),sbC=edit("NCDEX Sub Broker share per crore (₹)");sbN.setText("1000");sbM.setText("1000");sbC.setText("1000");root.addView(info("Sub Broker share / brokerage"));root.addView(sbN);root.addView(sbM);root.addView(sbC);root.addView(bal);
        addBtn("Save Client",v->{try{if(n.getText().toString().trim().isEmpty())throw new Exception("Client name required");long id=db.addClient(n.getText().toString(),code.getText().toString(),phone.getText().toString(),email.getText().toString());db.setBrokerage(id,"NSE","PER_CRORE",3000);db.setBrokerage(id,"MCX","PER_CRORE",3000);db.setBrokerage(id,"NCDEX","PER_CRORE",3000);long sbi=sbIds.get(sb.getSelectedItemPosition());if(sbi>0){db.setClientSubBroker(id,sbi);db.setSubBrokerage(id,sbi,"NSE","PER_CRORE",Double.parseDouble(sbN.getText().toString()),today());db.setSubBrokerage(id,sbi,"MCX","PER_CRORE",Double.parseDouble(sbM.getText().toString()),today());db.setSubBrokerage(id,sbi,"NCDEX","PER_CRORE",Double.parseDouble(sbC.getText().toString()),today());}if(bal.getText().length()>0)db.setOpeningBalance(id,today(),Double.parseDouble(bal.getText().toString()));clientDetail(id);}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->clients());}

    void clientDetail(long id){base("Client: "+db.clientName(id));long sbid=db.clientSubBroker(id);root.addView(info("Current balance: "+money(db.balance(id,today()))+"\nSub Broker: "+(sbid>0?db.subBrokerName(sbid)+" ["+db.subBrokerCode(sbid)+"]":"Direct / None")));root.addView(title("Client Brokerage + Sub Brokerage"));
        for(String ex:new String[]{"NSE","MCX","NCDEX"}){EditText e=edit(ex+" client brokerage per crore (₹)");e.setText("3000");root.addView(e);addBtn("Save "+ex+" Client Brokerage",v->{try{db.setBrokerage(id,ex,"PER_CRORE",Double.parseDouble(e.getText().toString()));toast("Client brokerage saved");}catch(Exception z){toast("Enter a number");}});if(sbid>0){EditText se=edit(ex+" sub-broker share per crore (₹)");se.setText("1000");root.addView(se);addBtn("Save "+ex+" Sub Broker Share",v->{try{db.setSubBrokerage(id,sbid,ex,"PER_CRORE",Double.parseDouble(se.getText().toString()),today());toast("Sub-broker share saved");}catch(Exception z){toast("Enter a number");}});}}
        addBtn("Change / Remove Sub Broker",v->changeClientSubBroker(id));addBtn("Add Payment",v->paymentFor(id));addBtn("View Ledger",v->ledger(id));addBtn("Back",v->clients());}

    void changeClientSubBroker(long id){base("Sub Broker - "+db.clientName(id));Spinner sb=new Spinner(this);ArrayList<Long> sbIds=new ArrayList<>();ArrayList<String> names=new ArrayList<>();sbIds.add(0L);names.add("Direct / No Sub Broker");Cursor c=db.subBrokers();while(c.moveToNext()){sbIds.add(c.getLong(0));names.add(c.getString(1)+" - "+c.getString(2));}c.close();sb.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(sb);addBtn("Save Sub Broker",v->{db.setClientSubBroker(id,sbIds.get(sb.getSelectedItemPosition()));toast("Sub Broker updated");clientDetail(id);});addBtn("Back",v->clientDetail(id));}

    void subBrokers(){base("Sub Brokers / Referral Partners");addBtn("+ Add Sub Broker",v->addSubBroker());Cursor c=db.subBrokers();while(c.moveToNext()){long id=c.getLong(0);String s=c.getString(1)+" - "+c.getString(2)+" | Clients: "+countSubBrokerClients(id)+" | Balance: "+money(db.subBrokerBalance(id,today()));addBtn(s,v->subBrokerDetail(id));}c.close();addBtn("Home",v->home());}
    int countSubBrokerClients(long sb){Cursor c=db.clientsForSubBroker(sb);int n=0;while(c.moveToNext())n++;c.close();return n;}
    void addSubBroker(){base("Add Sub Broker / Referral Partner");EditText code=edit("Sub Broker code *"),name=edit("Name *"),phone=edit("Phone"),email=edit("Email"),address=edit("Address"),bank=edit("Bank / Payment details"),opening=edit("Opening balance payable to sub broker");root.addView(code);root.addView(name);root.addView(phone);root.addView(email);root.addView(address);root.addView(bank);root.addView(opening);addBtn("Save Sub Broker",v->{try{if(code.getText().toString().trim().isEmpty()||name.getText().toString().trim().isEmpty())throw new Exception("Code and name required");long id=db.addSubBroker(code.getText().toString().trim(),name.getText().toString().trim(),phone.getText().toString(),email.getText().toString(),address.getText().toString(),bank.getText().toString());if(opening.getText().length()>0)db.setSubBrokerOpeningBalance(id,today(),Double.parseDouble(opening.getText().toString()));subBrokers();}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->subBrokers());}
    void subBrokerDetail(long sb){base("Sub Broker: "+db.subBrokerName(sb));root.addView(info("Code: "+db.subBrokerCode(sb)+"\nCurrent outstanding payable: "+money(db.subBrokerBalance(sb,today()))+"\nPeriod earnings: "+money(db.subBrokerEarningsTotal(sb,monthStart(),today()))));addBtn("View Referred Clients",v->subBrokerClients(sb));addBtn("Record Payment to Sub Broker",v->subBrokerPayment(sb));addBtn("View Sub Broker Ledger",v->subBrokerLedger(sb));addBtn("View Earnings",v->subBrokerEarnings(sb));addBtn("Back",v->subBrokers());}
    void subBrokerClients(long sb){base("Clients Referred by "+db.subBrokerName(sb));Cursor c=db.clientsForSubBroker(sb);while(c.moveToNext()){long id=c.getLong(0);addBtn(c.getString(1)+" ["+c.getString(2)+"] | "+money(db.balance(id,today())),v->clientDetail(id));}c.close();addBtn("Back",v->subBrokerDetail(sb));}
    void subBrokerPayment(long sb){base("Payment to Sub Broker - "+db.subBrokerName(sb));EditText d=edit("Payment date YYYY-MM-DD"),a=edit("Amount"),r=edit("Reference / UTR"),m=edit("Remarks");d.setText(today());Spinner typ=new Spinner(this);typ.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Bank Transfer","NEFT","RTGS","IMPS","UPI","Cheque","Cash","Other"}));root.addView(d);root.addView(a);root.addView(typ);root.addView(r);root.addView(m);addBtn("Save Sub Broker Payment",v->{try{db.addSubBrokerPayment(sb,d.getText().toString(),Double.parseDouble(a.getText().toString()),typ.getSelectedItem().toString(),r.getText().toString(),m.getText().toString());toast("Payment saved. Outstanding = "+money(db.subBrokerBalance(sb,d.getText().toString())));subBrokerDetail(sb);}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->subBrokerDetail(sb));}
    void subBrokerLedger(long sb){base("Sub Broker Ledger - "+db.subBrokerName(sb));EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);addBtn("Refresh Ledger",v->showSubBrokerLedger(sb,f.getText().toString(),t.getText().toString()));showSubBrokerLedger(sb,f.getText().toString(),t.getText().toString());addBtn("Back",v->subBrokerDetail(sb));}
    void showSubBrokerLedger(long sb,String f,String t){Cursor c=db.subBrokerLedger(sb,f,t);StringBuilder s=new StringBuilder("Date | Type | Debit | Credit\n\n");while(c.moveToNext())s.append(c.getString(0)).append(" | ").append(c.getString(1)).append("\n").append(c.getString(2)).append("\nDr ").append(money(c.getDouble(3))).append("  Cr ").append(money(c.getDouble(4))).append("\n\n");c.close();root.addView(info(s.toString()+"\nCurrent outstanding: "+money(db.subBrokerBalance(sb,t))));}
    void subBrokerEarnings(long sb){base("Sub Broker Earnings - "+db.subBrokerName(sb));EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);addBtn("Refresh Earnings",v->showSubBrokerEarnings(sb,f.getText().toString(),t.getText().toString()));showSubBrokerEarnings(sb,f.getText().toString(),t.getText().toString());addBtn("Back",v->subBrokerDetail(sb));}
    void showSubBrokerEarnings(long sb,String f,String t){Cursor c=db.subBrokerEarnings(sb,f,t);StringBuilder s=new StringBuilder("Date | Client | Exchange | Turnover | Client Brokerage | Sub Broker Earned\n\n");while(c.moveToNext())s.append(c.getString(0)).append(" | ").append(c.getString(1)).append(" | ").append(c.getString(2)).append("\nTurnover ").append(money(c.getDouble(3))).append(" | Brokerage ").append(money(c.getDouble(4))).append(" | Earned ").append(money(c.getDouble(5))).append("\n\n");c.close();s.append("Period total: ").append(money(db.subBrokerEarningsTotal(sb,f,t)));root.addView(info(s.toString()));}

    void trade(){
        base("Daily Trade Entry");
        LinearLayout intro=card();TextView t=new TextView(this);t.setText("Enter trade");t.setTextSize(18);t.setTypeface(null,1);t.setTextColor(Color.rgb(17,38,63));intro.addView(t);TextView d0=new TextView(this);d0.setText("The selected contract controls the lot size, quote unit and expiry. Gold 1 KG quoted per 10 GM is calculated as 100 quote units per lot.");d0.setTextSize(13);d0.setTextColor(Color.rgb(75,91,110));d0.setPadding(0,dp(5),0,0);intro.addView(d0);addCard(intro);addGap(8);

        LinearLayout tradeCard=card();
        tradeCard.addView(section("CLIENT & MARKET"));
        Spinner cs=new Spinner(this); ids.clear(); ArrayList<String> cn=new ArrayList<>(); Cursor cc=db.clients();
        while(cc.moveToNext()){ids.add(cc.getLong(0));cn.add(cc.getString(1)+(cc.getLong(7)>0?" • "+db.subBrokerName(cc.getLong(7)):" • Direct"));} cc.close();
        cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cn)); tradeCard.addView(cs);
        Spinner ex=new Spinner(this); ex.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"NSE","MCX","NCDEX"})); tradeCard.addView(ex);
        Spinner sym=new Spinner(this); tradeCard.addView(sym);
        Spinner con=new Spinner(this); tradeCard.addView(con);
        root.addView(tradeCard);addGap(8);

        LinearLayout selected=card();selected.addView(section("SELECTED CONTRACT"));
        TextView contractInfo=info("Select a product and expiry");selected.addView(contractInfo);
        TextView calc=info("Trade value will appear here");selected.addView(calc);addCard(selected);addGap(8);

        LinearLayout order=card();order.addView(section("ORDER DETAILS"));
        Spinner side=new Spinner(this);side.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"BUY","SELL"}));order.addView(side);
        EditText date=edit("Trade date YYYY-MM-DD"),lots=edit("Lots (e.g. 1)"),qty=edit("Quantity in lot unit (optional)"),rate=edit("Trade price"),notes=edit("Notes"); date.setText(today()); order.addView(date);order.addView(lots);order.addView(qty);order.addView(rate);order.addView(notes);addCard(order);

        ArrayList<Long> contractIds=new ArrayList<>();
        Runnable refreshCalc=()->{try{if(contractIds.size()==0)return;long cid=contractIds.get(Math.max(0,con.getSelectedItemPosition()));double lot=db.getLotSize(cid);double l=empty(lots)?0:Double.parseDouble(lots.getText().toString());double q=!empty(qty)?Double.parseDouble(qty.getText().toString()):0;double r=empty(rate)?0:Double.parseDouble(rate.getText().toString());double value=db.contractValue(cid,l,q,r);double quoteUnits=q>0?db.enteredQuantityToQuoteUnits(cid,q):db.lotToQuoteUnits(cid,l);calc.setText("Value: "+moneyPlain(value)+"   •   Quote quantity: "+formatQty(quoteUnits)+" "+db.quoteUnit(cid)+"   •   Lot size: "+formatQty(lot)+" "+db.lotUnit(cid));}catch(Exception ignored){}};
        TextWatcher tw=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){refreshCalc.run();}public void afterTextChanged(Editable e){}};lots.addTextChangedListener(tw);qty.addTextChangedListener(tw);rate.addTextChangedListener(tw);

        Runnable loadSymbols=()->{
            ArrayList<String> symbols=new ArrayList<>();LinkedHashMap<String,String> display=new LinkedHashMap<>();String exchange=ex.getSelectedItem().toString();Cursor c=db.contracts();while(c.moveToNext()){if(!exchange.equals(c.getString(1)))continue;String symbol=c.getString(2);double lot=c.getDouble(7);String unit=c.getString(9);if(!display.containsKey(symbol))display.put(symbol,symbol+" • Lot "+formatQty(lot)+" "+unit);}c.close();symbols.addAll(display.values());sym.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,symbols));if(symbols.size()>0)loadContractsForSymbol(db,exchange,sym,con,contractIds,contractInfo);else{contractIds.clear();contractInfo.setText("No products loaded for "+exchange+". Update Market Data first.");}};
        ex.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){loadSymbols.run();}});
        sym.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){loadContractsForSymbol(db,ex.getSelectedItem().toString(),sym,con,contractIds,contractInfo);refreshCalc.run();}});
        con.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(contractIds.size()>pos){contractInfo.setText(contractSummary(contractIds.get(pos)));refreshCalc.run();}}});

        addBtn("+ Other / Manual Instrument",v->manualInstrument());
        addBtn("Save Trade",v->{try{if(ids.size()==0)throw new Exception("Add a client first");if(contractIds.size()==0)throw new Exception("Select a product and expiry");long client=ids.get(cs.getSelectedItemPosition());long cid=contractIds.get(con.getSelectedItemPosition());double l=empty(lots)?0:Double.parseDouble(lots.getText().toString());double q=!empty(qty)?Double.parseDouble(qty.getText().toString()):0;if(l<=0&&q<=0)throw new Exception("Enter lots or quantity");double r=Double.parseDouble(rate.getText().toString());db.addTransaction(client,cid,date.getText().toString(),side.getSelectedItem().toString(),l,q,r,notes.getText().toString());toast("Trade saved • Value "+moneyPlain(db.contractValue(cid,l,q,r)));trade();}catch(Exception e){toast(e.getMessage());}});
        LinearLayout entries=card();entries.addView(section("TODAY'S ENTRIES"));root.addView(entries);showTodaysEntries();addBtn("Home",v->home());
    }

    void loadContractsForSymbol(DatabaseHelper d,String exchange,Spinner sym,Spinner con,ArrayList<Long> idsOut,TextView detail){if(sym.getSelectedItem()==null)return;String shown=sym.getSelectedItem().toString();String symbol=shown.split(" • Lot ")[0];loadContractsForSymbol(d,exchange,symbol,con,idsOut,detail);}
    void loadContractsForSymbol(DatabaseHelper d,String exchange,String symbol,Spinner con,ArrayList<Long> idsOut,TextView detail){idsOut.clear();ArrayList<String> names=new ArrayList<>();Cursor c=d.contracts();while(c.moveToNext()){if(!exchange.equals(c.getString(1))||!symbol.equals(c.getString(2)))continue;long id=c.getLong(0);idsOut.add(id);String expiry=c.getString(3);String lot=formatQty(c.getDouble(7))+" "+c.getString(9);String opt=c.getString(6);String strike=c.getDouble(5)>0?" • "+formatQty(c.getDouble(5)):"";double px=d.getPrice(id,today());double prev=d.latestClose(id,today());String label=(expiry==null||expiry.trim().isEmpty()?"No expiry":formatExpiry(expiry))+" • Lot "+lot;if(!opt.isEmpty())label+=" • "+opt+strike;label+=" • Close "+(px>0?moneyRate(px,c.getDouble(10),c.getString(11)):"not loaded");if(prev>0)label+=" • Prev "+moneyRate(prev,c.getDouble(10),c.getString(11));names.add(label);}c.close();con.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));if(idsOut.size()>0){con.setSelection(0);detail.setText(contractSummary(idsOut.get(0)));}else detail.setText("No expiry contracts loaded for "+symbol+". Run Market Data update.");}
    String contractSummary(long id){String expiry=expirySafe(id);double px=db.getPrice(id,today());double prev=db.latestClose(id,today());String value=px>0?moneyPlain(db.contractValue(id,1,0,px)):"Not available";return "Expiry: "+(expiry.isEmpty()?"Not specified":formatExpiry(expiry))+"\nLot Size: "+formatQty(db.getLotSize(id))+" "+db.lotUnit(id)+"\nPrice Quote: "+(px>0?moneyRate(px,db.quoteSize(id),db.quoteUnit(id)):"Not loaded")+"\nPrevious Close: "+(prev>0?moneyRate(prev,db.quoteSize(id),db.quoteUnit(id)):"Not loaded")+"\n1 Lot Value: "+value;}
    String formatExpiry(String x){try{String v=x.trim().toUpperCase(Locale.US);Date d=null;for(String f:new String[]{"ddMMMyyyy","ddMMMyy","ddMMyyyy","dd-MMM-yyyy","dd-MMM-yy"}){try{d=new SimpleDateFormat(f,Locale.US).parse(v);if(d!=null)break;}catch(Exception ignored){}}return d==null?x:new SimpleDateFormat("dd MMM yyyy",Locale.US).format(d);}catch(Exception e){return x;}}
    String moneyRate(double price,double quoteSize,String quoteUnit){if(price<=0)return "Not loaded";return "₹"+String.format(Locale.US,"%,.2f",price)+" / "+formatQty(quoteSize)+" "+quoteUnit;}
    String formatQty(double x){if(Math.abs(x-Math.rint(x))<0.000001)return String.format(Locale.US,"%.0f",x);return String.format(Locale.US,"%.3f",x);}
    String moneyPlain(double x){return "₹"+String.format(Locale.US,"%,.2f",Math.abs(x));}

    void manualInstrument(){
        base("Other / Manual Instrument"); root.addView(info("Use this when the share/commodity is not available in the downloaded contract list. It is stored as a MANUAL contract and does not overwrite the official market-data master."));
        Spinner ex=new Spinner(this);ex.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"NSE","MCX","NCDEX"}));root.addView(info("Exchange"));root.addView(ex);
        EditText name=edit("Share / Commodity name *"),expiry=edit("Expiry (optional for equity; e.g. 04DEC2026)"),lot=edit("Lot size in base unit *"),lotUnit=edit("Lot unit (e.g. SHARE, KG, GM) *"),quoteSize=edit("Quote size (e.g. 10 for ₹/10 GM) *"),quoteUnit=edit("Quote unit (e.g. GM) *"),strike=edit("Strike (0 if not applicable)"),opt=edit("Option type (CE/PE, optional)");lot.setText("1");lotUnit.setText("SHARE");quoteSize.setText("1");quoteUnit.setText("SHARE");strike.setText("0");root.addView(name);root.addView(expiry);root.addView(lot);root.addView(lotUnit);root.addView(quoteSize);root.addView(quoteUnit);root.addView(strike);root.addView(opt);
        addBtn("Save Manual Instrument",v->{try{if(empty(name))throw new Exception("Name required");long id=db.addManualContract(ex.getSelectedItem().toString(),name.getText().toString().trim(),expiry.getText().toString().trim(),"MANUAL",Double.parseDouble(lot.getText().toString()),lotUnit.getText().toString().trim(),Double.parseDouble(quoteSize.getText().toString()),quoteUnit.getText().toString().trim(),Double.parseDouble(strike.getText().toString()),opt.getText().toString().trim());toast("Manual instrument saved. Now enter the trade.");trade();}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->trade());
    }

    void showTodaysEntries(){Cursor c=db.transactionsForDate(today());int count=0;while(c.moveToNext()){count++;long id=c.getLong(0),contractId=c.getLong(1);String client=c.getString(2);String ex=c.getString(3);String sym=c.getString(4);String exp=c.getString(5);String side=c.getString(6);double lots=c.getDouble(7),qty=c.getDouble(8),rate=c.getDouble(9),value=c.getDouble(10);String label=client+" • "+ex+" • "+sym+(exp==null||exp.isEmpty()?"":" • "+formatExpiry(exp))+"\n"+side+" • "+formatQty(lots)+" lot • Qty "+formatQty(db.quoteUnitsToLotUnits(contractId,qty))+" "+db.lotUnit(contractId)+" • "+moneyPlain(rate)+" • Value "+moneyPlain(value);Button b=btn(label+"   ✏ Edit");b.setOnClickListener(v->editTrade(id));root.addView(b,new LinearLayout.LayoutParams(-1,-2));}c.close();if(count==0)root.addView(info("No trades entered today."));}

    void editTrade(long txId){
        Cursor c=db.transactionById(txId);if(!c.moveToFirst()){c.close();toast("Trade not found");return;}long clientId=c.getLong(1),contractId=c.getLong(2);String date0=c.getString(3),side0=c.getString(4),notes0=c.getString(8),exchange0=c.getString(9),symbol0=c.getString(10);double lots0=c.getDouble(5),qty0=c.getDouble(6),rate0=c.getDouble(7);c.close();
        base("Edit Trade");root.addView(info("Editing: "+symbol0+" | "+exchange0+" | "+db.lotUnit(contractId)+" | Lot "+formatQty(db.getLotSize(contractId))));
        Spinner cs=new Spinner(this);ids.clear();ArrayList<String> cn=new ArrayList<>();Cursor cc=db.clients();while(cc.moveToNext()){ids.add(cc.getLong(0));cn.add(cc.getString(1));}cc.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cn));for(int i=0;i<ids.size();i++)if(ids.get(i)==clientId)cs.setSelection(i);root.addView(cs);
        TextView contract=info("Contract: "+symbol0+(canceled(expirySafe(contractId))?"":" | "+expirySafe(contractId))+"\nLot: "+formatQty(db.getLotSize(contractId))+" "+db.lotUnit(contractId)+" | Quote: "+formatQty(db.quoteSize(contractId))+" "+db.quoteUnit(contractId));root.addView(contract);
        Spinner side=new Spinner(this);side.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"BUY","SELL"}));side.setSelection("SELL".equals(side0)?1:0);root.addView(side);EditText date=edit("Trade date"),lots=edit("Lots"),qty=edit("Quantity"),rate=edit("Trade price"),notes=edit("Notes");date.setText(date0);lots.setText(formatQty(lots0));qty.setText(formatQty(db.quoteUnitsToLotUnits(contractId,qty0)));rate.setText(String.valueOf(rate0));notes.setText(notes0);root.addView(date);root.addView(lots);root.addView(qty);root.addView(rate);root.addView(notes);
        addBtn("Save Changes",v->{try{long client=ids.get(cs.getSelectedItemPosition());double l=Double.parseDouble(lots.getText().toString()),q=Double.parseDouble(qty.getText().toString()),r=Double.parseDouble(rate.getText().toString());db.updateTransaction(txId,client,contractId,date.getText().toString(),side.getSelectedItem().toString(),l,q,r,notes.getText().toString());toast("Trade updated");trade();}catch(Exception e){toast(e.getMessage());}});addBtn("Cancel",v->trade());
    }
    String expirySafe(long id){Cursor c=db.contracts();while(c.moveToNext())if(c.getLong(0)==id){String x=c.getString(3);c.close();return x==null?"":x;}c.close();return "";}
    boolean canceled(String x){return x==null||x.isEmpty();}

    void marketData(){
        base("Market Data / Contract Master");
        LinearLayout c=card();
        c.addView(section("AUTOMATIC MARKET DATA UPDATE"));
        c.addView(info("Tap Update Market Data. The app automatically looks back for the latest available trading day and downloads contract/expiry data plus closing prices. Existing historical contracts and prices are retained."));
        TextView last=info("Latest loaded close: "+(db.latestPriceDateBefore(today()).isEmpty()?"None":db.latestPriceDateBefore(today())));
        c.addView(last);addCard(c);
        ProgressBar progress=new ProgressBar(this);progress.setVisibility(View.GONE);root.addView(progress,new LinearLayout.LayoutParams(-2,dp(40)));
        TextView status=info("Ready to update NSE, MCX and NCDEX.");root.addView(status);
        addBtn("🔄 Update Market Data Automatically",v->{
            progress.setVisibility(View.VISIBLE);status.setText("Downloading exchange market data… Please keep the app open.");
            new Thread(()->{
                try{
                    PriceUpdateManager.AutoResult r=PriceUpdateManager.updateAutomatic(this,db);
                    runOnUiThread(()->{
                        progress.setVisibility(View.GONE);
                        status.setText("Update complete.\n\n"+r.summary()+"\n\nTotal: "+r.contracts+" contract rows, "+r.prices+" price rows.");
                        last.setText("Latest loaded close: "+(db.latestPriceDateBefore(today()).isEmpty()?"None":db.latestPriceDateBefore(today())));
                        toast("Market data updated: "+r.contracts+" contracts / "+r.prices+" prices");
                    });
                }catch(Exception e){
                    runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Update failed: "+e.getMessage());toast("Market-data update failed. See status above.");});
                }
            },"market-data-update").start();
        });
        addBtn("View Loaded Expiries",v->showLoadedExpiries());
        addBtn("View Contract Count",v->toast("SQLite contracts: "+db.contractCount()));
        addBtn("Settings / Manual Data Sources",v->settings());
        addBtn("Back",v->home());
    }
    void showLoadedExpiries(){base("Loaded Expiry Contracts");Cursor c=db.contracts();int n=0;while(c.moveToNext()){String ex=c.getString(1),sym=c.getString(2),exp=c.getString(3);if(exp==null||exp.isEmpty()||"MASTER".equalsIgnoreCase(exp))continue;double prev=db.latestClose(c.getLong(0),today());TextView t=info(ex+" • "+sym+"\nExpiry "+formatExpiry(exp)+" • Lot "+formatQty(c.getDouble(7))+" "+c.getString(9)+" • Previous Close "+(prev>0?moneyRate(prev,c.getDouble(10),c.getString(11)):"Not loaded"));root.addView(t);addGap(4);n++;}c.close();if(n==0)root.addView(info("No expiry contracts are loaded yet. Configure an allowed contract-master/Bhavcopy source and run the update."));addBtn("Back",v->marketData());}
    void settlement(){base("Daily MTM / Weekly Settlement");Spinner cs=new Spinner(this);Cursor c=db.clients();ids.clear();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));}c.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(cs);EditText d=edit("Processing date YYYY-MM-DD");d.setText(today());root.addView(d);addBtn("Process Daily MTM",v->{try{double x=db.processDailyMtm(ids.get(cs.getSelectedItemPosition()),d.getText().toString());toast("Daily MTM = "+money(x));}catch(Exception e){toast(e.getMessage());}});addBtn("Settle Week / Carry Forward",v->{try{double x=db.settleWeek(ids.get(cs.getSelectedItemPosition()),d.getText().toString());toast("Weekly settlement = "+money(x)+". Settlement price is now the next carry-forward base.");}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->home());}
    void payments(){base("Payments / Client Ledger");Spinner cs=new Spinner(this);Cursor c=db.clients();ids.clear();ArrayList<String> n=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));n.add(c.getString(1));}c.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,n));root.addView(cs);addBtn("Record Payment",v->paymentFor(ids.get(cs.getSelectedItemPosition())));addBtn("View Ledger",v->ledger(ids.get(cs.getSelectedItemPosition())));addBtn("Back",v->home());}
    void paymentFor(long client){base("Record Payment - "+db.clientName(client));EditText d=edit("Payment date YYYY-MM-DD"),a=edit("Amount"),r=edit("Reference / UTR"),m=edit("Remarks");d.setText(today());Spinner typ=new Spinner(this);typ.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Bank Transfer","NEFT","RTGS","IMPS","UPI","Cheque","Cash","Other"}));root.addView(d);root.addView(a);root.addView(typ);root.addView(r);root.addView(m);addBtn("Save Payment",v->{try{db.addPayment(client,d.getText().toString(),Double.parseDouble(a.getText().toString()),typ.getSelectedItem().toString(),r.getText().toString(),m.getText().toString());toast("Payment saved. Balance = "+money(db.balance(client,d.getText().toString())));clientDetail(client);}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->clientDetail(client));}
    void ledger(long client){base("Ledger - "+db.clientName(client));EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);addBtn("Refresh Ledger",v->showLedger(client,f.getText().toString(),t.getText().toString()));showLedger(client,f.getText().toString(),t.getText().toString());addBtn("Back",v->clientDetail(client));}
    void showLedger(long client,String f,String t){Cursor c=db.ledger(client,f,t);StringBuilder s=new StringBuilder("Date | Type | Debit | Credit\n\n");while(c.moveToNext())s.append(c.getString(0)).append(" | ").append(c.getString(1)).append("\n").append(c.getString(2)).append("\nDr ").append(money(c.getDouble(3))).append("  Cr ").append(money(c.getDouble(4))).append("\n\n");c.close();root.addView(info(s.toString()+"\nCurrent balance: "+money(db.balance(client,t))));}
    void reports(){base("Daily / Weekly Reports");Spinner cs=new Spinner(this);Cursor c=db.clients();ids.clear();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){ids.add(c.getLong(0));names.add(c.getString(1));}c.close();cs.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(cs);EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(today());t.setText(today());root.addView(f);root.addView(t);addBtn("Generate PDF + Share",v->{try{File file=PdfReportGenerator.generate(this,db,ids.get(cs.getSelectedItemPosition()),f.getText().toString(),t.getText().toString());Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,androidx.core.content.FileProvider.getUriForFile(this,getPackageName()+".backup",file));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share report"));}catch(Exception e){toast(e.getMessage());}});addBtn("Process Daily MTM Before Report",v->{try{toast("MTM = "+money(db.processDailyMtm(ids.get(cs.getSelectedItemPosition()),t.getText().toString())));}catch(Exception e){toast(e.getMessage());}});addBtn("Back",v->home());}
    void subBrokerReports(){base("Sub Broker Reports / Payments");Cursor c=db.subBrokers();ids.clear();ArrayList<Long> sbIds=new ArrayList<>();ArrayList<String> names=new ArrayList<>();while(c.moveToNext()){sbIds.add(c.getLong(0));names.add(c.getString(1)+" - "+c.getString(2)+" | Outstanding "+money(db.subBrokerBalance(c.getLong(0),today())));}c.close();Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(s);EditText f=edit("From YYYY-MM-DD"),t=edit("To YYYY-MM-DD");f.setText(monthStart());t.setText(today());root.addView(f);root.addView(t);addBtn("View Selected Sub Broker",v->{if(sbIds.size()>0)subBrokerDetail(sbIds.get(s.getSelectedItemPosition()));else toast("No sub brokers registered");});addBtn("View Earnings",v->{if(sbIds.size()>0)subBrokerEarnings(sbIds.get(s.getSelectedItemPosition()));});addBtn("Record Payment",v->{if(sbIds.size()>0)subBrokerPayment(sbIds.get(s.getSelectedItemPosition()));});addBtn("Back",v->home());}
    void backup(){base("Backup & Restore");root.addView(info("Automatic daily backup is scheduled. Backups are stored locally first and can be shared using Android Share Sheet. Backup includes client/sub-broker masters, brokerage, earnings, ledgers, payments, trades, positions and market data."));addBtn("Backup Now",v->{try{toast("Created: "+BackupManager.backup(this).getName());}catch(Exception e){toast(e.getMessage());}});addBtn("Share Latest Backup",v->{try{File f=BackupManager.latest(this);if(!f.exists())f=BackupManager.backup(this);startActivity(Intent.createChooser(BackupManager.share(this,f),"Share backup"));}catch(Exception e){toast(e.getMessage());}});addBtn("Restore Backup",v->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/octet-stream").addCategory(Intent.CATEGORY_OPENABLE),9001));addBtn("Show Backup History",v->{File[] fs=BackupManager.history(this);StringBuilder s=new StringBuilder();for(File f:fs)s.append(f.getName()).append("\n");toast(s.length()==0?"No backups":s.toString());});addBtn("Back",v->home());}
    @Override protected void onActivityResult(int r,int result,Intent d){super.onActivityResult(r,result,d);if(r==9001&&result==RESULT_OK&&d!=null)try{BackupManager.restore(this,d.getData());toast("Restore complete. Restarting app.");new Handler().postDelayed(this::recreate,1000);}catch(Exception e){toast("Restore failed: "+e.getMessage());}}
    void settings(){base("Settings / Market Data Sources");root.addView(info("Automatic mode is the default. NSE uses its public UDiFF archive. NCDEX uses its public Common Files/Bhavcopy source. MCX is attempted from its public Bhav Copy page; if that page is bot-gated, the app can use the configured public EOD mirror. These sources do not require your NSE/MCX/NCDEX API credentials. Manual URLs are only fallbacks."));for(String ex:new String[]{"NSE","MCX","NCDEX"}){EditText e=edit(ex+" manual fallback URL (optional)");e.setText(db.setting(ex+"_URL"));root.addView(e);e.setTag(ex+"_URL");}addBtn("Save Fallback URLs",v->{for(int i=0;i<root.getChildCount();i++){View z=root.getChildAt(i);if(z instanceof EditText&&z.getTag()!=null)db.setting(z.getTag().toString(),((EditText)z).getText().toString());}toast("Fallback URLs saved");});addBtn("Back",v->home());}
    boolean empty(EditText e){return e.getText().toString().trim().isEmpty();}
    String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String previousTradingDate(){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,-1);while(c.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY||c.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)c.add(Calendar.DAY_OF_YEAR,-1);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    String monthStart(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_MONTH,1);return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    String money(double x){return String.format(Locale.US,"₹%,.2f %s",Math.abs(x),x<0?"Dr":"Cr");}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
