# GitHub APK workflow

1. Create a new GitHub repository.
2. Upload all files/folders inside `MarketClientManager` to the repository root.
3. Commit to `main`.
4. Open GitHub **Actions**.
5. Select **Build Android APK**.
6. Select **Run workflow**.
7. After completion, open the workflow run and download **market-client-manager-debug-apk** under Artifacts.
8. Transfer the APK to Android and install it. Android may ask you to allow installation from that source.

The app uses SQLite locally. Internet is only needed when you explicitly update market data from configured sources.
