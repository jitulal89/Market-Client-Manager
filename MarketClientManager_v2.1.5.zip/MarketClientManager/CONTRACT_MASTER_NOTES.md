# Bundled Contract Master

The APK ships with a bundled offline contract catalog in `app/src/main/assets/contracts_seed.csv`.

It includes the current NSE F&O underlying catalogue used as the seed list, the main MCX commodity/product catalogue, and the NCDEX futures catalogue. The sample also retains the contracts from the supplied Tejas Jalaram statement for testing.

Important: an exchange's exact tradable contract universe is dynamic. Expiry-specific futures and option contracts (including strikes) change over time. Therefore `MASTER` rows are catalog/template rows. The app must refresh the exact expiry/strike contract master from an allowed exchange source before those exact contracts are treated as current. NSE publishes its F&O contract file and permitted lot-size file; MCX publishes its current contract-available-for-trading table; NCDEX publishes contract lists and contract files.

Lot sizes marked as verified in the seed are only the values explicitly included for the sample/index contracts. Other catalog rows intentionally use a placeholder lot size of 1 until the exchange contract master refresh supplies the applicable lot size. Users should use quantity entry for those rows until refreshed.
