# Market Client Manager 2.1

Standalone Android app for maintaining NSE / MCX / NCDEX client trading accounts, daily MTM, weekly settlement/carry-forward, brokerage, payments, client balances, reports and backups.

## Core workflow

1. Install APK; bundled contract catalog is seeded into SQLite.
2. Configure allowed public/downloadable CSV/Bhavcopy/UDiFF sources in Settings.
3. Tap **Update Contract Master + Closing Prices**. The updater processes each configured exchange feed, upserts new contracts/expiries/strikes/lot sizes and stores closing/settlement prices in SQLite. Historical contracts are never deleted.
4. Enter client BUY/SELL trades. Enter lots or quantity; lot size is taken from contract master.
5. Process daily MTM. For an open position, the first base is the trade-derived position price; after a daily run, the prior close becomes the next daily base. After weekly settlement, the settlement price becomes the next week's carry-forward base.
6. Record client payments (bank transfer, NEFT, RTGS, IMPS, UPI, cheque, cash, other). The client ledger and balance update automatically.
7. Generate/share daily or weekly PDF statements.
8. Manage Sub Brokers / Referral Partners, client-to-sub-broker mapping, sub-broker brokerage share, earnings, separate ledger, payments and outstanding balances.
9. Automatic daily backup plus manual backup/share/restore.

## Weekly settlement logic

For an open long position, MTM = (current close - base price) × quantity. For a short position, the signed quantity makes the same formula work. On weekly settlement, the current settlement/closing price is recorded and becomes the next period's carry-forward base. The original trade price remains in the transaction history.

## Market-data note

The app is deliberately source-configurable. Do not use automated scraping or a data source unless its terms permit the intended use. NSE, MCX and NCDEX publish market-data/contract information through their own facilities, but access and redistribution terms apply.

## Build APK with GitHub Actions

1. Create a GitHub repository.
2. Extract this ZIP and upload the **MarketClientManager** folder contents to the repository root.
3. Commit to `main` or `master`.
4. Open **Actions → Build Android APK → Run workflow**.
5. Download the `market-client-manager-debug-apk` artifact.

The repository does not require Android Studio for the GitHub build.

## Sub Broker / Referral Partner workflow

A client may be linked to the person who referred the client. During client setup, configure both client brokerage and the Sub Broker share by exchange. Every eligible client trade records the Sub Broker ID and calculated Sub Broker earning. Earnings are posted to a separate Sub Broker ledger. Payments to the Sub Broker reduce that separate payable balance and do not alter the client trading account. See `SUB_BROKER_MODULE.md` for the detailed design.
